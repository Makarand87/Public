p <- read.csv("http://www.ats.ucla.edu/stat/data/poisson_sim.csv")
head(p)

p <- within(p, {
  prog <- factor(prog, levels=1:3, labels=c("General", "Academic", 
                                            "Vocational"))
  id <- factor(id)
})

summary(p)
hist(p$num_awards, labels = T)
hist(p$math, labels = T)


# The unconditional mean and variance of our outcome variable are not extremely different. 
# Our model assumes that these values, conditioned on the predictor variables, 
# will be equal (or at least roughly so).

with(p, tapply(num_awards, prog, function(X){ 
  sprintf("M (SD) = %1.2f (%1.2f)", mean(X), sd(X))
}))


mean(p$num_awards); var(p$num_awards)

tapply(p$num_awards, p$prog, mean)
tapply(p$num_awards, p$prog, sd)
library(ggplot2)
ggplot(p, aes(num_awards, fill=prog)) + 
  geom_histogram(binwidth = 0.5, position = "dodge")



##### 
m1 <- glm(num_awards ~ prog + math, family = "poisson", data=p)
summary(m1)
exp(coef(m1))
# Cameron and Trivedi (2009) recommended using robust standard errors for the parameter 
# estimates to control for mild violation of the distribution assumption that the variance equals the mean.
require(sandwich)
cov.m1 <- vcovHAC(m1, type="HC0")
cov.m1

std.err <- sqrt(diag(cov.m1))
std.err

r.est <- cbind("estimate"=coef(m1), "Robust SE" = std.err,
               "Pr(> |z|" = 2*pnorm(abs(coef(m1)/std.err), lower.tail=FALSE), 
               LL = coef(m1) -  1.96*std.err, 
               UL = coef(m1) + 1.96*std.err)
r.est

# goodness of fit test for the overall model. 
with(m1, cbind(res.deviance = deviance, df = df.residual,
               p = pchisq(deviance, df.residual, lower.tail=FALSE)))
# pchisq(deviance(m1), df.residual(m1), lower.tail = F)

# test the overall effect of prog
m2 <- update(m1, . ~ . - prog)
anova(m2,m1, test = "Chisq")
anova(m1,m2, test = "Chisq")

# regression results as incident rate ratios and their standard errors, together with the confidence interval. 
# To compute the standard error for the incident rate ratios, we will use the Delta method.
# install.packages("msm")
require(msm)
s <- deltamethod(list( ~ exp(x1), ~ exp(x2), ~ exp(x3), ~ exp(x4)), 
                                                                  coef(m1), cov.m1)
s
## exponentiate old estimates dropping the p values
rexp.est <- exp(r.est[,-3])
rexp.est
## replace SEs with estimates for exponentiated coefficients
rexp.est[,"Robust SE"] <- s
rexp.est

# expected marginal means. For example, what are the expected counts for each program type holding math score at its overall mean?
s1 <- data.frame(math=mean(p$math), 
                 prog = factor(1:3, levels=1:3, labels = levels(p$prog)))
s1

predict(m1, s1, type="response", se.fit=T)
p1 <- predict(m1, s1, type="response")

p1[2]/p1[1]
p1[3]/p1[1]

# graph the predicted number of events
p$phat <- predict(m1, type="response")
p <- p[with(p, order(prog, math)),]

ggplot(p, aes(x=math, y=phat, colour = prog)) + 
  geom_point(aes(y=num_awards), alpha=0.5, position = position_jitter(h=0.2)) +
  geom_line(size=1) + 
  labs(x="Math Score", y="Expected number of awards")
