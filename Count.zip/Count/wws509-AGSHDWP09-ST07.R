
# 2. Linear Models in R ---------------------------------------------------

setwd("C:\\Users\\makarand.ghule\\OneDrive - AGSHealth\\R Analysis\\Count")
fpe <- read.table("http://data.princeton.edu/wws509/datasets/effort.dat")
fpe


library(foreign)
fpe <- read.dta("http://data.princeton.edu/wws509/datasets/effort.dta")
View(fpe)
row.names(fpe) <- fpe$country
fpe$country <- NULL
View(fpe)
pairs(fpe)
pairs(fpe[,c("change", "setting", "effort")])
dev.print(png, "fing21.png", width=500, height=400)


png("pairs2.png", width=500, height=400)
pairs(fpe[,-1])
dev.off()



# 2.4 Simple Linear Regression --------------------------------------------
attach(fpe)
############################# NULL 
m0 <- lm(change ~ 1)
m0
summary(m0)
identical(as.numeric(m0$coefficients), mean(fpe$change))
confint(m0)
############################## Fitting a Linear Term
m1 <- lm(change ~ setting)
summary(m1)
anova(m1)
## Computing R-Squared by hand

rss <- function(lmfit) {
  sum(resid(lmfit)^2)
}

(Rsq <- 1 - rss(m1) / rss(m0))
cor(fpe)
cor.test(change, setting)

# Plotting Observed and Fitted Values
plot(setting,change,xlim=c(35,100))
abline(coef(m1))
 adj <- data.frame( pos=rep(4,nrow(fpe)), jit=0, row.names=row.names(fpe))
 adj[c("CostaRica","TrinidadTobago"),"pos"] <- 2
 adj[c("CostaRica","TrinidadTobago"),"jit"] <- c(1,-1)
 text(x = setting, y = change+adj$jit, labels = row.names(fpe), pos=adj$pos, cex=0.75)
 title("Figure 2.3. Fertility Change by Social Setting")
 dev.print(png,"fig23.png",width=600,height=480)

 par(mfrow=c(2,2)) 
 plot(m1)
 par(mfrow=c(1,1))
 
 m2 <- lm(change ~ effort) 
 summary(m2)
 anova(m2)
 cor(fpe)
 cor.test(change, effort)
 1201.1+1449.1 == 1699.65+950.55
 
 
 
# 2.5 Multiple Linear Regression ------------------------------------------
mlr1 <- lm(change ~ effort + setting)
summary(mlr1)
anova(mlr1)
anova(mlr1, m1)
anova(m2)
mlr2 <- lm(change ~ setting + effort)
anova(mlr2)
mlr2$assign
cor(fpe)

# 2.5.6 More Complicated Models -------------------------------------------

mcm <- lm(change ~ effort*setting)
summary(mcm)


# 2.6 One-Way Analysis of Variance ----------------------------------------
setting.g <- cut(setting,
                 breaks=c(min(setting),70,80,max(setting)),
                 right=FALSE,include.lowest=TRUE, 
                 labels=c("Low","Medium","High")
                 )
setting.g

data.frame(min=tapply(setting, setting.g, min), 
           max=tapply(setting, setting.g, max))

tapply(change, setting.g, mean)

m1g <- lm(change ~ setting.g)
summary(m1g)
anova(m1g)
# Dummy Variables
settingMedium <- as.numeric(setting.g == "Medium")
settingHigh <- as.numeric(setting.g == "High")
m2g <- lm(change ~ settingMedium + settingHigh)
coef(m2g)

# 3.6 Multi-factor Models: Model Selection

cuse <- read.table("http://data.princeton.edu/wws509/datasets/cuse.dat", header=TRUE)

cuse$nomore <- as.numeric(cuse$wantsMore == "no")
cuse$education <- ordered(cuse$education, levels=c("low","high"))
cuse$n = cuse$using + cuse$notUsing
cuse$Y <- cbind(cuse$using, cuse$notUsing)
cuse
str(cuse)

rhs <- c("1","age", "education", "nomore",
         "age + education", "age + nomore", "education + nomore", 
         "age * education", "age * nomore", "education * nomore", 
         "age + education + nomore",
         "age * education + nomore", "age * nomore + education", 
         "age + education * nomore", "age * (education + nomore)", 
         "education * (age + nomore)", "(age + education) * nomore", 
         "age*education*nomore - age:education:nomore")


fit <- function(lp) glm(paste("Y",lp,sep="~"),family=binomial,data=cuse)

models <- vector("list",length(rhs))

for(i in 1:length(rhs)){
  models[[i]] <- fit(rhs[i])
}


data.frame(
  # model = rhs,  
  model = unlist(lapply(lapply(models,formula),deparse)),
  deviance = round(unlist(lapply(models,deviance)),2),
  df = unlist(lapply(models,df.residual))
)
summary(models[[11]])















# 3. Logit Models for Binary Data -----------------------------------------

library(foreign)
# cuse <- read.dta("http://data.princeton.edu/wws509/datasets/cusew.dta")
cuseRaw <- read.dta("http://data.princeton.edu/wws509/datasets/cuse.dta")
# cuseRaw2 <- read.table("http://data.princeton.edu/wws509/datasets/cuse.raw")

summary(cuseRaw)
# mean(cuseRaw$n)
# tapply(cuseRaw$n, cuseRaw$cuse, sum)
# cuse$Y <- cbind(cuse$using, cuse$notUsing)
# str(cuse)
# summary(cuse)
# 
# m1 <- glm(Y ~ 1, family = binomial, data = cuse)

k2x2 <- data.frame(tapply(cuseRaw$n, list(cuseRaw$desire, cuseRaw$cuse), sum))
k2x2$n <- rowSums(k2x2)
k2x2
colnames(k2x2) <- c("notUsing", "Using")
k2x2[,"nomore"] <- rownames(k2x2)
rownames(k2x2) <- NULL
k2x2
k2x2$nomore <- if (rownames(k2x2)=="Wants more") 0  else 1
k2x2
