# install.packages("RODBC")
library(RODBC)
channel <- odbcConnect(dsn = "SQL")

# Active <- sqlFetch(channel, "AttAnalysis_tblActiveEmployees")
Inactive <- sqlFetch(channel, "AttAnalysis_tblInActiveEmployees")
# install.packages("sqldf")
library(sqldf)

filtered <- sqldf("SELECT DISTINCT t1.AGSExperienceInMonths, 
          t1.TransportMode, 
          t1.WorkFacility, 
          t1.MaritalStatus, 
          t1.Gender, 
          t1.Last30DaysLeaveCount, 
          t1.CourseLevels, 
          /* COUNT_of_EmployeeCode */
            (COUNT(t1.EmployeeCode)) AS COUNT
      FROM Inactive t1
      WHERE t1.VerticalName = 'Accounts Receivable' and JobRole = 'Team Member'
      GROUP BY t1.AGSExperienceInMonths,
               t1.TransportMode,
               t1.WorkFacility,
               t1.MaritalStatus,
               t1.Gender,
               t1.Last30DaysLeaveCount,
               t1.CourseLevels
      ORDER BY COUNT DESC")
max(filtered$COUNT)
hist(filtered$COUNT, labels = T, breaks = max(filtered$COUNT))
mean(filtered$COUNT); var(filtered$COUNT)
