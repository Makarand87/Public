
# 2. Linear Models in R ---------------------------------------------------

setwd("C:\\Users\\makarand.ghule\\OneDrive - AGSHealth\\R Analysis\\Count")
fpe <- read.table("http://data.princeton.edu/wws509/datasets/effort.dat")
fpe


library(foreign)
fpe <- read.dta("http://data.princeton.edu/wws509/datasets/effort.dta")
View(fpe)
row.names(fpe) <- fpe$country
fpe$country <- NULL
View(fpe)
pairs(fpe)
pairs(fpe[,c("change", "setting", "effort")])
dev.print(png, "fing21.png", width=500, height=400)


png("pairs2.png", width=500, height=400)
pairs(fpe[,-1])
dev.off()



# 2.4 Simple Linear Regression --------------------------------------------
attach(fpe)
############################# NULL 
m0 <- lm(change ~ 1)
m0
summary(m0)
identical(as.numeric(m0$coefficients), mean(fpe$change))
confint(m0)
############################## Fitting a Linear Term
m1 <- lm(change ~ setting)
summary(m1)
anova(m1)
## Computing R-Squared by hand

rss <- function(lmfit) {
  sum(resid(lmfit)^2)
}

(Rsq <- 1 - rss(m1) / rss(m0))
cor(fpe)
cor.test(change, setting)

# Plotting Observed and Fitted Values
plot(setting,change,xlim=c(35,100))
abline(coef(m1))
 adj <- data.frame( pos=rep(4,nrow(fpe)), jit=0, row.names=row.names(fpe))
 adj[c("CostaRica","TrinidadTobago"),"pos"] <- 2
 adj[c("CostaRica","TrinidadTobago"),"jit"] <- c(1,-1)
 text(x = setting, y = change+adj$jit, labels = row.names(fpe), pos=adj$pos, cex=0.75)
 title("Figure 2.3. Fertility Change by Social Setting")
 dev.print(png,"fig23.png",width=600,height=480)

 par(mfrow=c(2,2)) 
 plot(m1)
 par(mfrow=c(1,1))
 
 m2 <- lm(change ~ effort) 
 summary(m2)
 anova(m2)
 cor(fpe)
 cor.test(change, effort)
 1201.1+1449.1 == 1699.65+950.55
 
 
 
# 2.5 Multiple Linear Regression ------------------------------------------
mlr1 <- lm(change ~ effort + setting)
summary(mlr1)
anova(mlr1)
anova(mlr1, m1)
anova(m2)
mlr2 <- lm(change ~ setting + effort)
anova(mlr2)
mlr2$assign
cor(fpe)

# 2.5.6 More Complicated Models -------------------------------------------

mcm <- lm(change ~ effort*setting)
summary(mcm)


# 2.6 One-Way Analysis of Variance ----------------------------------------
setting.g <- cut(setting,
                 breaks=c(min(setting),70,80,max(setting)),
                 right=FALSE,include.lowest=TRUE, 
                 labels=c("Low","Medium","High")
                 )
setting.g

data.frame(min=tapply(setting, setting.g, min), 
           max=tapply(setting, setting.g, max))

tapply(change, setting.g, mean)

m1g <- lm(change ~ setting.g)
summary(m1g)
anova(m1g)
# Dummy Variables
settingMedium <- as.numeric(setting.g == "Medium")
settingHigh <- as.numeric(setting.g == "High")
m2g <- lm(change ~ settingMedium + settingHigh)
coef(m2g)

# 3.6 Multi-factor Models: Model Selection

cuse <- read.table("http://data.princeton.edu/wws509/datasets/cuse.dat", header=TRUE)

cuse$nomore <- as.numeric(cuse$wantsMore == "no")
cuse$education <- ordered(cuse$education, levels=c("low","high"))
cuse$n = cuse$using + cuse$notUsing
cuse$Y <- cbind(cuse$using, cuse$notUsing)
cuse
str(cuse)

rhs <- c("1","age", "education", "nomore",
         "age + education", "age + nomore", "education + nomore", 
         "age * education", "age * nomore", "education * nomore", 
         "age + education + nomore",
         "age * education + nomore", "age * nomore + education", 
         "age + education * nomore", "age * (education + nomore)", 
         "education * (age + nomore)", "(age + education) * nomore", 
         "age*education*nomore - age:education:nomore")


fit <- function(lp) glm(paste("Y",lp,sep="~"),family=binomial,data=cuse)

models <- vector("list",length(rhs))

for(i in 1:length(rhs)){
  models[[i]] <- fit(rhs[i])
}


data.frame(
  # model = rhs,  
  model = unlist(lapply(lapply(models,formula),deparse)),
  deviance = round(unlist(lapply(models,deviance)),2),
  df = unlist(lapply(models,df.residual))
)
summary(models[[11]])















# 3. Logit Models for Binary Data -----------------------------------------

library(foreign)
cuse <- read.dta("http://data.princeton.edu/wws509/datasets/cusew.dta")
cuseRaw <- read.dta("http://data.princeton.edu/wws509/datasets/cuse.dta")
# cuseRaw2 <- read.table("http://data.princeton.edu/wws509/datasets/cuse.raw")

summary(cuseRaw)
# mean(cuseRaw$n)
# tapply(cuseRaw$n, cuseRaw$cuse, sum)
# cuse$Y <- cbind(cuse$using, cuse$notUsing)
# str(cuse)
# summary(cuse)
# 
# m1 <- glm(Y ~ 1, family = binomial, data = cuse)

k2x2 <- data.frame(tapply(cuseRaw$n, list(cuseRaw$desire, cuseRaw$cuse), sum))
k2x2$n <- rowSums(k2x2)
k2x2
colnames(k2x2) <- c("notUsing", "Using", "n")
k2x2[,"nomore"] <- c(0,1)
rownames(k2x2) <- NULL
k2x2 <- k2x2[,c(4,2,1,3)]
k2x2



# Testing Homogeneity -----------------------------------------------------

k2x2$Y <- cbind(k2x2$Using, k2x2$notUsing)
k2x2
# In R the outcome with individual data is a vector of ones and zeroes, 
# but with grouped data it is a matrix with counts of successes and failures, 
# which we create first:
m0 <- glm(Y ~ 1, data=k2x2, family = binomial)
summary(m0)

# It is easy to verify that the estimate of the constant is the logit of the proportion using contraception:
p <- sum(k2x2$Using)/sum(k2x2$n)  
  
log(p/(1-p))
# qlogis(p) # quantiles of the standard logistic distribution
# You can verify that the estimated standard error of the observed logit is the square root of 1/successes + 1/failures
sqrt(1/sum(k2x2$Using) + 1/sum(k2x2$notUsing))

confint(m0)
plogis(confint(m0))



# Pearson's chi-squared statistic:
obs <- k2x2$Y
fit <- cbind(p*k2x2$n, (1-p)*k2x2$n)
sum((obs-fit)^2/fit)


# The Odds Ratio ----------------------------------------------------------

mD <- glm(Y ~ nomore, data=k2x2, family=binomial)
summary(mD)

exp(coef(mD))[2]
k2x2
288/635
219/972
0.454/0.225

exp(coef(mD))[2]/(1+exp(coef(mD))[2])

b <- coef(mD)
se <- sqrt(diag(vcov(mD)))
(b[2]/se[2])^2 #The result is Wald's statistic for testing the hypothesis that the coef of nomore is zero, or equivalently that the odds-ratio is one.



# 3.4 The Comparison of Several Groups ------------------------------------

cuse <- tapply(cuseRaw$n, list(cuseRaw$age, cuseRaw$cuse), sum)
rowSums(cuse)
cuse <- cbind(cuse, data.frame(rowSums(cuse)))
colnames(cuse)[3] <- "n"
cuse
cuse$age <- rownames(cuse)
rownames(cuse) <- NULL
cuse <- cuse[,c(4,2,1,3)]
cuse$Y <- cbind(cuse$Yes, cuse$No)
cuse
str(cuse)

# The One-Factor Model

mA <- glm(Y ~ age, data=cuse, family=binomial)
summary(mA)
