# Install and load the survival package

# install.packages("survival")
library(survival)

# sort the aml data by time
aml
aml=aml[order(aml$time),]

aml
# Create graph of length of time that each subject was in the study
with(aml, plot(time, type="h"))

# Create the life table survival object for aml
# Create the life table for the aml data
# The functions survfit() and Surv() create a life table survival object.
# The summary() function displays the life table
# The life table object is passed to the plot() function to create the KM plot.
aml.survfit = survfit(Surv(time, status == 1) ~ 1, data=aml)
aml.survfit
summary(aml.survfit)

# Plot the Kaplan-Meier curve for aml. Don't print the confidence interval.
plot(aml.survfit, xlab = "Time (weeks)", ylab="Proportion surviving", conf.int=FALSE, main="Survival in AML")

# Kaplan-Meier curve for aml with the confidence bounds. 
plot(aml.survfit, xlab = "Time", ylab="Proportion surviving")

# Create aml life tables and KM plots broken out by treatment (x,  "Maintained" vs. "Not maintained")
surv.by.aml.rx = survfit(Surv(time, status == 1) ~ x, data = aml)
surv.by.aml.rx
summary(surv.by.aml.rx)

# Plot KM 
plot(surv.by.aml.rx, xlab = "Time", ylab="Survival",col=c("black", "red"), lty = 1:2, main="Kaplan-Meier Survival vs. Maintenance in AML")

# Add legend
legend("topright", c("Maintained", "Not maintained"), lty = 1:2, col=c("black", "red"), cex = 0.5)

# Perform the log rank test using the R function survdiff().
surv.diff.aml= survdiff(Surv(time, status == 1) ~ x, data=aml)

surv.diff.aml

# Cox Proportional Hazards regression
# melanoma data set from ISwR package, described in Dalgaard Chapter 12. 
# The ISwR package currently only appears to be available for older versions of R

# install.packages("ISwR")

library(ISwR)

help(melanom) # description of the melanoma data
head(melanom)

# The log rank test is a special case of the cox proportional hazard regression analysis.
# The same analysis can be performed using the R function coxph().
# melanoma example using a log-rank test.
surv.diff.sex = survdiff(Surv(days, status == 1) ~ sex, data = melanom)

surv.diff.sex

# melanoma analysis using Cox proportional hazards regression
coxph.sex = coxph(Surv(days, status == 1) ~ sex, data = melanom)

summary(coxph.sex)

# melanoma Cox analysis including covariate ulcer thickness

# Plot the thickness values and log(thickness)
hist(melanom$thick)

hist(log(melanom$thick))
# Examine thickness by sex
boxplot(log(melanom$thick) ~ melanom$sex)

t.test(log(melanom$thick) ~ melanom$sex)


# The Cox PH analysis of melanoma data including covariate log(thick)

coxph.sex.thick = coxph(Surv(days, status == 1) ~ sex + log(thick), data = melanom)
summary(coxph.sex.thick)




# Test of proportional hazards assumption
coxph.sex = coxph(Surv(days, status == 1) ~ sex, data = melanom)

cox.zph(coxph.sex)




# Survival tree analysis using the rpart package[edit]
# Rpart and the example are described in the PDF document "An Introduction to Recursive Partitioning Using the RPART Routines". Terry M. Therneau, Elizabeth J. Atkinson, Mayo Foundation. September 3, 1997.

# install.packages("rpart")
library(rpart)
help(stagec)
head(stagec)

# Pass a survival object from Surv() to the function rpart() to perform the analysis.
fit <- rpart(Surv(pgtime, pgstat) ~ age + eet + g2 + grade + gleason + ploidy, data=stagec)

# # plot the resulting tree
# dev.new()
# par("mar")
# par("fin")
# # par(mar=c(5.1,4.1,4.1,2.1)
# par(mar=c(2.1,4.1,2.1,2.1))
# par(mai=c(1.02,0.82,0.82,0.42))
# par("mai")/par("mar")
# plot(1:10, ann = F, type="n", xaxt="n", yaxt="n")
# for(j in 1:4) for (i in 0:10) mtext(as.character(i), side=j, line=i)
############
# par(mar=c(5,6,4,2)+0.1,mgp=c(5,1,0))
plot(fit, uniform=T, branch=.4, compress=T);text(fit, use.n=T)
# The print() function provides details of the tree not shown above
print(fit)




install.packages("randomForestSRC")
library(help="randomForestSRC")
library("randomForestSRC")

## classification analysis -----------------------------------------------------------
## 
data(breast, package = "randomForestSRC")
help(breast, package = "randomForestSRC")
str(breast)

breast <- na.omit(breast)
obj <- rfsrc(status ~ ., data=breast, nsplit=10)
print(obj)
plot(obj)
plot.rfsrc(obj)
plot.competing.risk(obj)
plot.survival(obj, cens.model = "rfsrc")


data("veteran", package = "randomForestSRC")
v.obj <- rfsrc(Surv(time, status) ~ ., data=veteran, ntree = 100)
plot(v.obj)
print(v.obj)
plot.rfsrc(v.obj)
plot.survival(v.obj, cens.model = "rfsrc")
# install.packages("glmnet")
library("glmnet")
## pbc data
data(pbc, package = "randomForestSRC")
pbc.obj <- rfsrc(Surv(days, status) ~ ., pbc, nsplit = 10)

# default spline approach
plot.survival(pbc.obj, subset = 3)
plot.survival(pbc.obj, subset = 3, k = 100)

# three-parameter generalized gamma is approximately the same
# but notice that its CHF estimate (blue line) is not as accurate
plot.survival(pbc.obj, subset = 3, haz.model = "ggamma")

# nonparametric method is too wiggly or undersmooths
plot.survival(pbc.obj, subset = 3, haz.model = "nonpar", span = 0.1)
plot.survival(pbc.obj, subset = 3, haz.model = "nonpar", span = 0.8)

## ------------------------------------------------------------
## competing risk example
## ------------------------------------------------------------

## use the pbc data from the survival package
## events are transplant (1) and death (2)
if (library("survival", logical.return = TRUE)) {
  data(pbc, package = "survival")
  pbc$id <- NULL
  plot(rfsrc(Surv(time, status) ~ ., pbc, nsplit = 10, tree.err = TRUE))
}


## ------------------------------------------------------------
## multivariate mixed forests
## ------------------------------------------------------------

mtcars.new <- mtcars
mtcars.new$cyl <- factor(mtcars.new$cyl)
mtcars.new$carb <- factor(mtcars.new$carb, ordered = TRUE)
mv.obj <- rfsrc(cbind(carb, mpg, cyl) ~., data = mtcars.new, tree.err = TRUE)
plot(mv.obj, outcome.target = "carb")
plot(mv.obj, outcome.target = "mpg")
plot(mv.obj, outcome.target = "cyl")

## Not run: 
## ------------------------------------------------------------
## follicular cell lymphoma
## ------------------------------------------------------------

  data(follic, package = "randomForestSRC")
  follic.obj <- rfsrc(Surv(time, status) ~ ., follic, nsplit = 3, ntree = 100)
  plot.competing.risk(follic.obj)
  
  # ## ------------------------------------------------------------
  # ## competing risk analysis of pbc data from the survival package
  # ## events are transplant (1) and death (2)
  # ## ------------------------------------------------------------
  
  
  if (library("survival", logical.return = TRUE)) {
     data(pbc, package = "survival")
     pbc$id <- NULL
     plot.competing.risk(rfsrc(Surv(time, status) ~ ., pbc, nsplit = 10), cex=0.5)
  }
  