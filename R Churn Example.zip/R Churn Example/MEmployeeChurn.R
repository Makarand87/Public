############ 1. INPUT AND EXPLORATION ############


MFG10YearTerminationData <- read.csv("D:/Mac/R/R Churn Example/MFG10YearTerminationData.csv")
MYdataset <- MFG10YearTerminationData
str(MYdataset)
summary(MYdataset)
# install.packages("plyr")
# install.packages("dplyr")

library(plyr)
library(dplyr)

StatusCount<- as.data.frame.matrix(MYdataset %>%
                                     group_by(STATUS_YEAR) %>%
                                     select(STATUS) %>%
                                     table())

StatusCount$TOTAL<-StatusCount$ACTIVE + StatusCount$TERMINATED
StatusCount$PercentTerminated <-StatusCount$TERMINATED/(StatusCount$TOTAL)*100
StatusCount

mean(StatusCount$PercentTerminated)

# install.packages("ggplot2")
library(ggplot2)
ggplot() + geom_bar(aes(y = ..count..,x =as.factor(BUSINESS_UNIT),fill = as.factor(STATUS)),data=MYdataset)


TerminatesData<- as.data.frame(MYdataset %>%
                                 filter(STATUS=="TERMINATED"))
ggplot() + geom_bar(aes(y = ..count..,x =as.factor(STATUS_YEAR),fill = as.factor(termtype_desc)),data=TerminatesData)


ggplot() + geom_bar(aes(y = ..count..,x =as.factor(STATUS_YEAR),fill = as.factor(termreason_desc)),data=TerminatesData)



ggplot() + geom_bar(aes(y = ..count..,x =as.factor(department_name),fill = as.factor(termreason_desc)),data=TerminatesData,position = position_stack())+
  theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))

# install.packages("caret")
library(caret)
# install.packages("lattice")
featurePlot(x=MYdataset[,6:7],y=MYdataset$STATUS,plot="density",auto.key = list(columns = 2))

featurePlot(x=MYdataset[,6:7],y=MYdataset$STATUS,plot="box",auto.key = list(columns = 2))

# install.packages("rattle")
# install.packages("magrittr")
building <- TRUE
scoring <- !building


seed <- 42

########## 2. BUILDING MODELS ##############


MFG10YearTerminationData <- read.csv("D:/Mac/R/R Churn Example/MFG10YearTerminationData.csv")
MYdataset <- MFG10YearTerminationData

set.seed(42)
Mynobs <- nrow(MYdataset)
MYsample <- MYtrain <- subset(MYdataset, STATUS_YEAR <= 2014)
MYvalidate <- NULL
MYtest <- subset(MYdataset, STATUS_YEAR == 2015)


MYinput <- c("age", "length_of_service", "gender_full",
             "STATUS_YEAR", "BUSINESS_UNIT")
MYnumeric <- c("age", "length_of_service", "STATUS_YEAR")
MYcategoric <- c(
  "gender_full", "BUSINESS_UNIT")
MYtarget <- "STATUS"
MYrisk <- NULL
MYident <- "EmployeeID"
MYignore <- c("recorddate_key", "birthdate_key", "orighiredate_key", "terminationdate_key", "city_name", "job_title", "store_name")
MYweights <- NULL
MYTrainingData<-MYtrain[c(MYinput, MYtarget)]
MYTestingData<-MYtest[c(MYinput, MYtarget)]



# ########### Decision Tree ################
# install.packages("rattle")
library(rattle)
# install.packages("rpart")
library(rpart)
set.seed(42)

MTrpart <- rpart(STATUS - ., data=MyTrain[, c(MYinput, MYtarget)], method="class", parms=list(split="information"), control=rpart.control(usesurrogate=0,maxsurrogate=0))


MYrpart <- rpart(STATUS ~ ., data=MYtrain[, c(MYinput, MYtarget)], method="class", parms=list(split="information"), control=rpart.control(usesurrogate=0,maxsurrogate=0))


print(MYrpart)
printcp(MYrpart)
cat("\n")

install.packages("rpart.plot"); install.packages("randomForest")
fancyRpartPlot(MYrpart, main="Decision Tree MFG10YearTerminationData $ STATUS")

##############  Random Forest model and Generate textual output of 'Random Forest' model ####
library(randomForest, quietly=TRUE)

set.seed(42)
MYrf <- randomForest::randomForest(STATUS ~ ., data=MYtrain[c(MYinput, MYtarget)], ntree=500, mtry=2, importance=TRUE, na.action(randomForest::na.roughfix, replace=FALSE)
)
MYrf

# Calculate the AUC Confidence Interval
# install.packages("pROC")
library(pROC)
pROC::roc(MYrf$y, as.numeric(MYrf$predicted))

pROC::ci.auc(MYrf$y, as.numeric(MYrf$predicted))

# List the importance of the variables.
rn <- round(randomForest::importance(MYrf), 2)
rn[order(rn[,3], decreasing = TRUE),]


####################### ADABOOST ##################
# install.packages("ada")
library(ada)

set.seed(42)
Myada <- ada::ada (STATUS ~ ., data=MYtrain[c(MYinput, MYtarget)],
                    control=rpart::rpart.control(maxdepth=30,
                                                 cp=0.01, 
                                                 minsplit=20,
                                                 xval=10), iter=50)


print(Myada)

round(Myada$model$errs[Myada$iter,],2)
cat('Variables actually used in tree construction:\n')
print(sort(names(listAdaVarsUsed(Myada))))
cat("\n nFrequency of variables actually used:\n")
print(listAdaVarsUsed(Myada))



#################### Support Vector Machine ################

install.packages("kernlab")
library(kernlab, quietly= TRUE)

set.seed(42)
MYksvm <- ksvm(as.factor(STATUS) ~ ., data=MYtrain[c(MYinput, MYtarget)], kernel='rbfdot', prob.model=TRUE)


MYksvm


#####################  Linear Model ############
MYglm <- glm(STATUS ~ ., data=MYtrain[c(MYinput, MYtarget)], family=binomial(link="logit"))

print(summary(MYglm))


cat(sprintf("Log Likelihood: %.3f (%d df)\n", 
            logLik(MYglm)[1], 
            attr(logLik(MYglm), "df")))

cat(sprintf("Null/Residual deviance difference: %.3f (%d df)\n",
            MYglm$null.deviance-MYglm$deviance,
            MYglm$df.null-MYglm$df.residual))


cat(sprintf("Chi-square p-value: %.8f\n",
            dchisq(MYglm$null.deviance-MYglm$deviance,
                   MYglm$df.null-MYglm$df.residual)))

cat(sprintf("Pseudo R-Square (optimistic): %.8f\n",
            cor(MYglm$y, MYglm$fitted.values)))


cat('\n==== ANOVA ====\n\n')
print(anova(MYglm, test="Chisq"))
cat("\n")


########### 3. EVALUATING MODELS ########### 


#### 3.1 Error Matricies for decision Tree ####

MYpr <- predict(MYrpart, newdata=MYtest[c(MYinput, MYtarget)], type="class")
table(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr, dnn=c("Actual", "Predicted"))

pcme <- function(actual, cl) 
  { 
    x <- table(actual, cl)
    nc <- nrow(x)
    tbl <- cbind(x/length(actual),
             Error=sapply(1:nc, 
                          function(r) round(sum(x[r,-r])/sum(x[r,]),2)))
    names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
    return(tbl)
}


per <- pcme(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr)
round(per,2)

# Calculate the overall error percentage.
cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))

# Calculate the averaged class error percentage.
cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))



### 3.2 Error Matricies for Adaboost  ####

MYpr <- predict(Myada, newdata=MYtest[c(MYinput, MYtarget)])
table(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr, dnn=c("Actual", "Predicted"))

# Generate the confusion matrix showing proportions.
pcme <- function(actual, cl)
{
  x <- table(actual, cl)
  nc <- nrow(x)
  tbl <- cbind(x/length(actual),
               Error=sapply(1:nc,
                            function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
  names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
  return(tbl)
}
per <- pcme(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr)
round(per, 2)

# Calculate the overall error percentage.
cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))

# Calculate the averaged class error percentage.
cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))



# 3.3 Error Matricies for Random Forest model. ####

# Obtain the response from the Random Forest model.
MYpr <- predict(MYrf, newdata=na.omit(MYtest[c(MYinput, MYtarget)]))
# Generate the confusion matrix showing counts.
table(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS, MYpr,
      dnn=c("Actual", "Predicted"))
 
# Generate the confusion matrix showing proportions.
pcme <- function(actual, cl)
{
  x <- table(actual, cl)
  nc <- nrow(x)
  tbl <- cbind(x/length(actual),
               Error=sapply(1:nc,
                            function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
  names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
  return(tbl)
}
per <- pcme(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS, MYpr)
round(per, 2)

# Calculate the overall error percentage.
cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))
 
# Calculate the averaged class error percentage.
cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))



# 3.4 Error Matrix for the Support Vector Model  ####

# Obtain the response from the SVM model.
MYpr <- kernlab::predict(MYksvm, newdata=na.omit(MYtest[c(MYinput, MYtarget)]))

# Generate the confusion matrix showing counts.
table(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS, MYpr,dnn=c("Actual", "Predicted"))


 
pcme <- function(actual, cl)
{
  x <- table(actual, cl)
  nc <- nrow(x)
  tbl <- cbind(x/length(actual),
               Error=sapply(1:nc,
                            function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
  names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
  return(tbl)
}
per <- pcme(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS, MYpr)
round(per, 2)


# Calculate the overall error percentage.
cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))

# Calculate the averaged class error percentage.
cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))

# ### 3.5 Generate an Error Matrix for the Linear model. ####
# Obtain the response from the Linear model.
MYpr <- as.vector(ifelse(predict(MYglm, type="response", newdata=MYtest[c(MYinput, MYtarget)]) > 0.5, "TERMINATED", "ACTIVE"))

# Generate the confusion matrix showing counts.
 table(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr,
                               dnn=c("Actual", "Predicted"))
## Predicted
## Actual ACTIVE
  ## ACTIVE 4799
     ## TERMINATED 162
# Generate the confusion matrix showing proportions.
 pcme <- function(actual, cl)
 {
   x <- table(actual, cl)
   nc <- nrow(x)
   tbl <- cbind(x/length(actual),
                Error=sapply(1:nc,
                             function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
   names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
   return(tbl)
 }
                         
                         
 per <- pcme(MYtest[c(MYinput, MYtarget)]$STATUS, MYpr)
 round(per, 2)
                         
                         
 # Calculate the overall error percentage.
 cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))
 
 # Calculate the averaged class error percentage.
 cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))
 
 ########### Area Under Curve (AUC) ######
 
 # install.packages("ROCR")
 library(ROCR)
 library(ggplot2, quietly=TRUE)
 MYpr <- predict(MYrpart, newdata=MYtest[c(MYinput, MYtarget)])[,2]
 
 
 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 pe <- performance(pred, "tpr", "fpr")
 au <- performance(pred, "auc")@y.values[[1]]
 pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
 p <- ggplot(pd, aes(x=fpr, y=tpr))
 p <- p + geom_line(colour="red")
 p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
 p <- p + ggtitle("ROC Curve Decision Tree MFG10YearTerminationData [test] STATUS")
 p <- p + theme(plot.title=element_text(size=10))
 p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
 p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                   label=paste("AUC =", round(au, 2)))
 print(p)
 
 
 # Calculate the area under the curve for the plot.
 
 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 performance(pred, "auc")
 
 ### ADABOOST ####
 MYpr <- predict(Myada, newdata=MYtest[c(MYinput, MYtarget)], type="prob")[,2]
 
 
 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 pe <- performance(pred, "tpr", "fpr")
 au <- performance(pred, "auc")@y.values[[1]]
 pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
 p <- ggplot(pd, aes(x=fpr, y=tpr))
 p <- p + geom_line(colour="red")
 p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
 p <- p + ggtitle("ROC Curve Ada Boost MFG10YearTerminationData [test] STATUS")
 p <- p + theme(plot.title=element_text(size=10))
 p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
 p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                   label=paste("AUC =", round(au, 2)))
 print(p)
 
 
 # Calculate the area under the curve for the plot.
 # Remove observations with missing target.
 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 performance(pred, "auc")
 
 #### Random Forest ####
 MYpr <- predict(MYrf, newdata=na.omit(MYtest[c(MYinput, MYtarget)]), type="prob")[,2]
 
 no.miss <- na.omit(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 pe <- performance(pred, "tpr", "fpr")
 au <- performance(pred, "auc")@y.values[[1]]
 pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
 p <- ggplot(pd, aes(x=fpr, y=tpr))
 p <- p + geom_line(colour="red")
 p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
 p <- p + ggtitle("ROC Curve Random Forest MFG10YearTerminationData [test] STATUS")
 p <- p + theme(plot.title=element_text(size=10))
 p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
 p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                   label=paste("AUC =", round(au, 2)))
 print(p)
 
 
 # Calculate the area under the curve for the plot.
 # Remove observations with missing target.
 no.miss <- na.omit(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 performance(pred, "auc")
  
 
 ## SVM ####
 MYpr <- kernlab::predict(MYksvm, newdata=na.omit(MYtest[c(MYinput, MYtarget)]), type="probabilities")[,2]
 # Remove observations with missing target.
 no.miss <- na.omit(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 pe <- performance(pred, "tpr", "fpr")
 au <- performance(pred, "auc")@y.values[[1]]
 pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
 p <- ggplot(pd, aes(x=fpr, y=tpr))
 p <- p + geom_line(colour="red")
 p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
 p <- p + ggtitle("ROC Curve SVM MFG10YearTerminationData [test] STATUS")
 p <- p + theme(plot.title=element_text(size=10))
 p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
 p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                   label=paste("AUC =", round(au, 2)))
 print(p)
 
 # Calculate the area under the curve for the plot.
 # Remove observations with missing target.
 no.miss <- na.omit(na.omit(MYtest[c(MYinput, MYtarget)])$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 performance(pred, "auc")
 
 
 ##### GLM #####
 MYpr <- predict(MYglm, type="response", newdata=MYtest[c(MYinput, MYtarget)])
 # Remove observations with missing target.
 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 pe <- performance(pred, "tpr", "fpr")
 au <- performance(pred, "auc")@y.values[[1]]
 pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
 p <- ggplot(pd, aes(x=fpr, y=tpr))
 p <- p + geom_line(colour="red")
 p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
 p <- p + ggtitle("ROC Curve Linear MFG10YearTerminationData [test] STATUS")
 p <- p + theme(plot.title=element_text(size=10))
 p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
 p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                   label=paste("AUC =", round(au, 2)))
 print(p)

 no.miss <- na.omit(MYtest[c(MYinput, MYtarget)]$STATUS)
 miss.list <- attr(no.miss, "na.action")
 attributes(no.miss) <- NULL
 if (length(miss.list))
 {
   pred <- prediction(MYpr[-miss.list], no.miss)
 } else
 {
   pred <- prediction(MYpr, no.miss)
 }
 performance(pred, "auc")