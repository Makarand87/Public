############# 1.INPUT ############# 


AttritionData <- read.csv("D:/HR/Attrition Analysis/R Analysis/20161110.csv")
MYdataset <- AttritionData

# colnames(MYdataset)
MYnobs <- nrow(MYdataset); MYnobs
# str(MYdataset)
# summary(MYdataset)
summary(MYdataset$JobRole)

############# 2.Data Preparation ############# 

set.seed(100)
library(magrittr);
library(mice)


MYtrain <- subset(MYdataset, RelievingYear <= 2015); nrow(MYtrain)

MYtest <- subset(MYdataset, RelievingYear == 2016 & Department != 'Data Integration'); nrow(MYtest) 

# MYtest <- subset(MYdataset, STATUS_YEAR == 2016 ); nrow(MYtest) 

MYinput <- c('EmployeeAge',
             'MaritalStatus',
             'WorkLocation',
             "ExperienceType",
             'ProdAvgDuringNotice',
             'QualAvgDuringNotice',
             'Last30DaysLeaveCount',
             "LastReviewRating",
             'Department',
             'Shift_Name',
             'Gender'
             # 'ExperienceInAGS'
             # ,"TotalExtraHoursWorked"
             # "Vertical",
             # "Function",
             # "DepartmentGroup",
             # "Rating.Bracket",
             # "Experience.Range"
             # ,"Distance"
             # ,'EngagementIndex'
             # ,"RptEmployeeCode"
              )

MYnumeric <- c('AGE',
               'ProdAvgDuringNotice',
               'QualAvgDuringNotice',
               'Last30DaysLeaveCount',
               "LastReviewRating",
               'ExperienceInAGS',
               "TotalExtraHoursWorked",
               "Distance"
               )


MYcategoric <- c('MaritalStatus',
                 'WorkLocation',
                 "ExperienceType",
                 'EngagementIndex',
                 'Department',
                 'Shift_Name',
                 'Gender',
                 "Vertical",
                 "Function",
                 "Department",
                 "DepartmentGroup",
                 "Shift_Name",
                 "Rating.Bracket",
                 "Experience.Range",
                 "RptEmployeeCode"
)

MYvalidate <- NULL
MYrisk <- NULL
MYweights <- NULL


MYtarget <- "Attrition"
summary(MYTrainingData$Attrition)
MYident <- "EmployeeCode"


MYTrainingData<-MYtrain[c(MYinput, MYtarget)] 
 nrow(MYTrainingData);head(MYTrainingData)
# imputed = complete(mice(MYTrainingData))
# summary(MYTrainingData)
MYNumericData<-MYtrain[c(MYnumeric, MYtarget)]  #numeric



MYTestingData<-MYtest[c(MYinput, MYtarget)]




############# 3. EXPLORATION   ############

cor(MYNumericData)

library(plyr);library(dplyr)

StatusCount<- as.data.frame.matrix(MYdataset %>%
                                     group_by(ExpAGSRange) %>%
                                     select(Availability_Filter) %>%
                                     table())
StatusCount$TOTAL<-StatusCount$`Current Employee` + StatusCount$`Employee Left`
StatusCount$PercentTerminated <-StatusCount$`Employee Left`/(StatusCount$TOTAL)*100
StatusCount
mean(StatusCount$PercentTerminated)

library(ggplot2)
ggplot() + geom_bar(aes(y = ..count.., x=as.factor(DepartmentGroup), fill = as.factor(Availability_Filter)), data=MYdataset, position=position_stack())


TerminatesData<- as.data.frame(MYdataset %>% 
                                 filter(Availability_Filter == "Employee Left"))
#exitType
ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

# Reason of Leaving
ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ReasonofLeaving)), data=TerminatesData, position = position_stack())

# Departments
ggplot() + geom_bar(aes(y=..count.., x=as.factor(Department), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

ggplot() + geom_bar(aes(y=..count.., x=as.factor(WorkLocation), fill=as.factor(Department)), data=TerminatesData, position = position_stack())


ggplot() + geom_bar(aes(y=..count.., x=as.factor(WorkLocation), fill=as.factor(Vertical)), data=TerminatesData, position = position_stack())


library(caret)
featurePlot(x=MYdataset[,c(15,17)], y=MYdataset$Availability_Filter, plot="density", auto.key=list(column=2))

featurePlot(x=MYdataset[,c(15,17)], y=MYdataset$Availability_Filter, plot="box", auto.key=list(column=2))





#============================================================


# 3.1 Decision Tree  ####


library(rpart, quietly=TRUE)

set.seed(100)

MYrpart <- rpart(Attrition ~ ., 
                 data=MYTrainingData, 
                 method="class", 
                 parms=list(split="information"),
                 control = rpart.control(usesurrogate=0,
                                         maxsurrogate = 0
                                         )
                 )

print(MYrpart)
printcp(MYrpart)

library(rpart.plot); library(rattle)
fancyRpartPlot(MYrpart, main="Decision Tree Attrition Data $ Attrition")


# 3.2 Evaluate model performance. Decision Tree #####


MYpr <- predict(MYrpart, 
                newdata= MYTestingData,
                  type="class"
                )

table (MYtest[c(MYinput,MYtarget)]$Attrition,
       MYpr, dnn=c("Actual", "Predicted"))

# Confusion matrix showing proportions. ####

pcme <- function(actual, cl)
{
  x <- table(actual, cl)
  nc <- nrow(x)
  tbl <- cbind(x/length(actual),
               Error=sapply(1:nc,
                            function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
  names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
  return(tbl)
}
per <- pcme(MYtest[c(MYinput, MYtarget)]$Attrition, MYpr)
round(per, 2)

# Calculate the overall error percentage.

cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))

# Calculate the averaged class error percentage.

cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))



library(ggplot2, quietly=TRUE); library(ROCR)

# ROC  ###
MYpr <- predict(MYrpart, newdata=MYTestingData)[,2]

# Remove observations with missing target.

no.miss   <- na.omit(MYTestingData$Attrition)
miss.list <- attr(no.miss, "na.action")
attributes(no.miss) <- NULL

if (length(miss.list))
{
  pred <- prediction(MYpr[-miss.list], no.miss)
} else
{
  pred <- prediction(MYpr, no.miss)
}

pe <- performance(pred, "tpr", "fpr")
au <- performance(pred, "auc")@y.values[[1]]
pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
p <- ggplot(pd, aes(x=fpr, y=tpr))
p <- p + geom_line(colour="red")
p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
p <- p + ggtitle("ROC Curve Decision Tree [test] Attrition")
p <- p + theme(plot.title=element_text(size=10))
p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                  label=paste("AUC =", round(au, 2)))
print(p)



# AUC ####

performance(pred, "auc")

# Precision/Recall Plot

ROCR::plot(performance(pred, "prec", "rec"), col="#CC0000FF", lty=1, add=FALSE)

title(main="Precision/Recall Plot on test data")


# Sensitivity/Specificity Plot for rpart model 

ROCR::plot(performance(pred, "sens", "spec"), col="#CC0000FF", lty=1, add=FALSE)

title(main="Sensitivity/Specificity (tpr/tnr) [test]")
grid()

#============================================================
