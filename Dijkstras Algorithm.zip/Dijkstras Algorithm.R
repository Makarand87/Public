library(igraph)

# your data
mat <- as.matrix(read.table(text=
"
node	SL	CH	IN	LV	NV	CI	LX	KV	CO	CL	CN	MT	GR	HB	WA	RI
SL	0	300	245	263	312	0	0	0	0	0	0	0	0	0	0	0
CH	300	0	201	0	0	0	0	0	0	362	0	0	0	0	0	0
IN	245	201	0	114	0	112	0	0	176	0	0	0	0	0	0	0
LV	263	0	114	0	175	0	86	0	0	0	0	0	0	0	0	0
NV	312	0	0	175	0	0	0	180	0	0	0	0	0	0	0	0
CI	0	0	112	0	0	0	95	0	105	0	204	0	0	0	0	0
LX	0	0	0	86	0	95	0	170	0	0	177	0	0	0	0	0
KV	0	0	0	0	180	0	170	0	0	0	0	0	299	0	0	0
CO	0	0	176	0	0	105	0	0	0	142	0	0	0	0	0	0
CL	0	362	0	0	0	0	0	0	142	0	251	201	0	332	0	0
CN	0	0	0	0	0	204	177	0	0	251	0	157	244	0	0	318
MT	0	0	0	0	0	0	0	0	0	201	157	0	0	213	209	0
GR	0	0	0	0	0	0	0	299	0	0	244	0	0	0	0	205
HB	0	0	0	0	0	0	0	0	0	332	0	213	0	0	120	0
WA	0	0	0	0	0	0	0	0	0	0	0	209	0	120	0	111
RI	0	0	0	0	0	0	0	0	0	0	318	0	205	0	111	0
"
, header=T))

# prepare data for graph functions - set NA to zero to indicate no direct edge
nms <- mat[,1]
mat <- mat[, -1]
colnames(mat) <- rownames(mat) <- nms
mat[is.na(mat)] <- 0
mat


# create graph from adjacency matrix
g <- graph.adjacency(mat, weighted=TRUE, add.rownames = "code")
plot.igraph(g)
layout_on_grid(g)
layout_nicely(g)
plot(g, layout=layout_on_grid) 
layout_randomly(g)
rglplot(g, layout=layout_on_grid(g, dim = 3))

with_lgl(g)

# Get all path distances
(s.paths <- shortest.paths(g, algorithm = "dijkstra"))

(s.paths <- shortest.paths(g, "SL", algorithm = "dijkstra"))


s.paths <- all_shortest_paths(g, "SL")

distances(g, algorithm = "dijkstra")
#  ------------------------------------------------------------------------

g <- make_ring(10) 
distances(g) 
shortest_paths(g, 5) 
all_shortest_paths(g, 1, 6:8) 
mean_distance(g) 
## Weighted shortest paths
el <- matrix(nc=3, 
             byrow=TRUE, c(1,2,0, 1,3,2, 1,4,1, 2,3,0, 2,5,5, 2,6,2, 3,2,1, 3,4,1, 
                           3,7,1, 4,3,0, 4,7,2, 5,6,2, 5,8,8, 6,3,2, 6,7,1, 6,9,1, 
                           6,10,3, 8,6,1, 8,9,1, 9,10,4) ) 
g2 <- add_edges(make_empty_graph(10), t(el[,1:2]), weight=el[,3]) 
distances(g2, mode="out")
