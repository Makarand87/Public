require(foreign)

ceb <- read.dta("http://data.princeton.edu/wws509/datasets/ceb.dta")
View(ceb)
str(ceb)
summary(ceb)

mean(ceb$mean); mean(ceb$var)
var(ceb$mean); var(ceb$var)
apply(ceb,2, length)
s <- subset(ceb, n>20)
View(s)
plot(log(s$mean), log(s$var), 
     xlab="log(Mean CEB)",  ylab="log(Variance of CEB)", 
     main="Figure 4.1. Mean-Variance Relationship")
mtext("Children Ever Born in Fiji, 1976", padj=-0.5)
abline(0,1)


ceb$y <- round(ceb$mean*ceb$n)
View(ceb)
ceb$os = log(ceb$n)

m0 <- glm(y ~ offset(os), data=ceb, family=poisson)
summary(m0)
pchisq(deviance(m0), df.residual(m0), lower.tail = F)


exp(coef(m0))
sum(ceb$y);sum(ceb$n)
sum(ceb$y)/sum(ceb$n)

mlr <- glm(y ~ res + offset(os), data=ceb, family=poisson)
summary(mlr)
exp(coef(mlr))
print(anova(mlr, test="Chisq"))
pchisq(deviance(mlr), df.residual(mlr), lower.tail = F)

mle <- glm(y ~ educ + offset(os), data=ceb, family = poisson)
summary(mle)
exp(coef(mle))
anova(mle, "Chisq")
pchisq(deviance(mle), df.residual(mle), lower.tail = F)

mld <- glm(y ~ dur + offset(os), data=ceb, family=poisson)
summary(mld)
exp(coef(mld))[-1]
c(deviance(m0)-deviance(mld), mld$df - mld$df.residual, deviance(mld))


m2dr <- glm( y ~ dur + res + offset(os), data=ceb, family=poisson)
summary(m2dr)
exp(coef(m2dr))[-1]
pchisq(deviance(m2dr), df.residual(m2dr), lower.tail = F)

m2de <- glm( y ~ dur + educ + offset(os), data=ceb, family=poisson)
pchisq(deviance(m2de), df.residual(m2de), lower.tail = F)

m2dxr <- glm( y ~ dur * res + offset(os), data=ceb, family=poisson)
pchisq(deviance(m2dxr), df.residual(m2dxr), lower.tail = F)

m2dxe <- glm(y ~ dur * educ + offset(os), data = ceb, family=poisson)
pchisq(deviance(m2dxe), df.residual(m2dxe), lower.tail = F)

deviance(m2de);deviance(m2dr)
deviance(m2dxe); deviance(m2dxr)


m3 <- glm(y ~ dur + educ + res + offset(os), data=ceb, family = poisson)
summary(m3)
pchisq(deviance(m3), df.residual(m3), lower.tail = F)
?pchisq

exp(coef(m3))



#####################

library(foreign)
 ab <- read.dta("http://www.stata-press.com/data/lf2/couart2.dta")

 names(ab) 
View(ab)
r <- c(mean(ab$art), var(ab$art)) 

c(mean=r[1], var=r[2], Ratio=r[2]/r[1])

mp <- glm(art ~ ., data=ab, family=poisson)
summary(mp)
exp(coef(mp))

qchisq(0.95, df.residual(mp))

pr <- residuals(mp, "pearson")
c(sum(pr^2), deviance(mp))



# 4.A.1. Extra-Poisson Variation ------------------------------------------

phi  <- sum(pr^2)/df.residual(mp)
round(c(phi, sqrt(phi)), 4)


mq <- glm(art ~., data=ab, family=quasipoisson)
summary(mq)

se <- function(model) sqrt(diag(vcov(model)))
round(data.frame(p=coef(mp), q=coef(mq), se.p=se(mp), se.q=se(mq), ratio=se(mq)/se(mp)),4)


# 4.A.2 Negative Binomial Regression --------------------------------------

library(MASS)
mnb <- glm.nb(art ~ ., data=ab)
summary(mnb)

1/mnb$theta
-2*(logLik(mp) - logLik(mnb))

mnbg <- glm(art ~., data=ab, family=negative.binomial(mnb$theta))
all(abs(coef(mnb) == coef(mnbg)) < 1e-12)


### Unobserved Heterogeneity

v=1/mnb$theta
x = seq(0.0, 3, 0.1)
gd = data.frame(x = seq(0.0, 3, 0.1), g = dgamma(x, shape = 1/v, scale = v))
library(ggplot2)
ggplot(gd, aes(x,g)) + geom_line()

qgamma((1:3)/4, shape = 1/v, scale=v)

round(data.frame(
     p=coef(mp),q=coef(mq),nb=coef(mnb),
     se.p=se(mp),se.q=se(mq),se.nb=se(mnb)),4)


# Goodness of fit

deviance(mnbg)

xb <- predict(mnb)
g <- cut(xb, breaks=quantile(xb, seq(0,100,5)/100))
m <- tapply(ab$art, g, mean)
v <- tapply(ab$art, g, var)
plot(m,v, xlab="Mean", ylab="Variance", 
       main="Mean-Variance Relationship")
mtext("Articles Published by Ph.D. Biochemists",padj=-0.5)
x <- seq(0,4,0.02)
lines(x,x*phi, lty=2,col=2)
lines(x, x*(1+x/mnb$theta), lty=3, col=3)
legend("topleft", lty=2:3,col=2:3, legend=c("Q.Poisson","Neg. Binomial"), inset=0.02, cex = 0.7)



# 4.A.3 Zero-Inflated Poisson Models --------------------------------------

zobs <- ab$art==0
zpoi <- exp(-exp(predict(mp)))
zpoi <- dpois(0,exp(predict(mp)))
c(obs=mean(zobs), poi=mean(zpoi))
  
install.packages("pscl")
library(pscl)
mzip <- zeroinfl(art ~., data = ab)
summary(mzip)


pi <- predict(mzip, type="zero")
mu <- predict(mzip, type="count")
zip <- pi + (1-pi)*exp(-mu)
mean(zip)


munb <- exp(predict(mnb))
theta <- mnb$theta
znb <- (theta/(munb+theta))^theta
mean(znb)
d <- dnbinom(0,mu=munb, size = theta)
mean(d)


### AIC
c(nb=AIC(mnb), zip=AIC(mzip))

# By hand
mzip$rank <- length(coef(mzip))
aic <- function(model) -2*logLik(model) + 2*model$rank
sapply(list(mnb,mzip), aic)
