data(nym.2002, package="UsingR")

time = sort(nym.2002$time)
max(time)/median(time)
min(time)/median(time)

plot(time/median(time), ylim=c(1/4,4))
abline(h=c(1/2,1,2))

plot(log2(time/median(time)),ylim=c(-2,2))
abline(h=-1:1)


data(ChickWeight)
head(ChickWeight)
plot( ChickWeight$Time, ChickWeight$weight, col=ChickWeight$Diet)

chick = reshape(ChickWeight, idvar=c("Chick","Diet"), timevar="Time",
                direction="wide")

head(chick)
chick = na.omit(chick)
#write.csv(ChickWeight, "ChickWeight.csv")
#write.csv(chick, "Chick.csv")

(sum(chick$weight.4) + 3000)/(nrow(chick)+1)/mean(chick$weight.4)
mean(c(chick$weight.4, 3000))/mean(chick$weight.4)

median(c(chick$weight.4, 3000))/median(chick$weight.4)

sd(c(chick$weight.4, 3000))/sd(chick$weight.4)

mad(c(chick$weight.4, 3000))/mad(chick$weight.4)

cor(x,y)

cor(x, y, method="spearman")

par(mfrow=c(1,1))
plot(chick$weight.4, chick$weight.21)


a <- cor(chick$weight.4, chick$weight.21)
b <- cor(c(chick$weight.4,3000), c(chick$weight.21,3000))

b/a



############  Mann-Whitney-Wilcoxon Test ##############


library(dplyr)
x <- filter(chick, Diet==1) %>% select(weight.4) %>% unlist
y <- filter(chick, Diet==4) %>% select(weight.4) %>% unlist
t.test(x,y)

wilcox.test(x,y)

t.test(c(x,200),y)$p.val
wilcox.test(c(x,200),y)$p.val

#library(rafalib)
   # mypar(1,3)
    par(mfcol=c(1,3))
boxplot(x,y)
    boxplot(x,y+10)
    boxplot(x,y+100)


t.test(x,y+10)$statistic - t.test(x,y+100)$statistic

#wilcox.test(x,y+10)$statistic - wilcox.test(x,y+100)$statistic

wilcox.test(c(1,2,3),c(4,5,6))
wilcox.test(c(1,2,3),c(400,500,600))


##############################################################

data(nym.2002, package="UsingR")

time = sort(nym.2002$time)
max(time)/median(time)
min(time)/median(time)

plot(time/median(time), ylim=c(1/4,4))
abline(h=c(1/2,1,2))

plot(log2(time/median(time)),ylim=c(-2,2))
abline(h=-1:1)


data(ChickWeight)
head(ChickWeight)
plot( ChickWeight$Time, ChickWeight$weight, col=ChickWeight$Diet)

chick = reshape(ChickWeight, idvar=c("Chick","Diet"), timevar="Time",
                direction="wide")

head(chick)
chick = na.omit(chick)
#write.csv(ChickWeight, "ChickWeight.csv")
#write.csv(chick, "Chick.csv")

(sum(chick$weight.4) + 3000)/(nrow(chick)+1)/mean(chick$weight.4)
mean(c(chick$weight.4, 3000))/mean(chick$weight.4)

median(c(chick$weight.4, 3000))/median(chick$weight.4)

sd(c(chick$weight.4, 3000))/sd(chick$weight.4)

mad(c(chick$weight.4, 3000))/mad(chick$weight.4)

cor(x,y)

cor(x, y, method="spearman")

par(mfrow=c(1,1))
plot(chick$weight.4, chick$weight.21)


a <- cor(chick$weight.4, chick$weight.21)
b <- cor(c(chick$weight.4,3000), c(chick$weight.21,3000))

b/a



############  Mann-Whitney-Wilcoxon Test ##############


library(dplyr)
x <- filter(chick, Diet==1) %>% select(weight.4) %>% unlist
y <- filter(chick, Diet==4) %>% select(weight.4) %>% unlist
t.test(x,y)

wilcox.test(x,y)

t.test(c(x,200),y)$p.val
wilcox.test(c(x,200),y)$p.val

#library(rafalib)
   # mypar(1,3)
    par(mfcol=c(1,3))
boxplot(x,y)
    boxplot(x,y+10)
    boxplot(x,y+100)


t.test(x,y+10)$statistic - t.test(x,y+100)$statistic

#wilcox.test(x,y+10)$statistic - wilcox.test(x,y+100)$statistic

wilcox.test(c(1,2,3),c(4,5,6))
wilcox.test(c(1,2,3),c(400,500,600))





x=1:10
X <- cbind(x,2*x,3*x,4*x,5*x)
sum(X[7,])
x=1:40;X=matrix(1:60,20,3,byrow=TRUE)
X[,3]
head(X)


X  =  matrix(c(3,2,1,5, 4,2,-1,0, -5,2,5,0, 1,-1, -5, 1),4,4)
X
Y <- c(10,5,7,4);Y
solve(X,Y)

a <- matrix(1:12, nrow=4);a
b <- matrix(1:15, nrow=3);b

d <- a%*%b
d[ 3,2 ]

sum(b[,2] * a[3,])



X <- matrix(c(1,1,1,1,0,0,1,1),nrow=4)
rownames(X) <- c("a","a","b","b");X

beta <- c(5, 2)
X %*% beta

X <- matrix(c(1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,1,1),nrow=6)
rownames(X) <- c("a","a","b","b","c","c");X

beta <- c(10,3,-3)
X %*% beta
##################################

install.packages("downloader")
library(downloader) 
url <-  "https://raw.githubusercontent.com/genomicsclass/dagdata/master/inst/extdata/femaleMiceWeights.csv" 
filename <- "femaleMiceWeights.csv" 
download(url, destfile=filename)
ls()
setwd("C:/Users/makarand.ghule/OneDrive - AGSHealth/R Analysis/Statistics and R")

dat <- read.csv("femaleMiceWeights.csv")
str(dat)
plot(dat$Bodyweight ~ dat$Diet, vertical=TRUE)
stripchart(dat$Bodyweight ~ dat$Diet, vertical=TRUE, method="jitter")
X <- model.matrix(~Diet, data=dat)
head(X)
Y <- dat$Bodyweight
solve(t(X) %*% X) %*% (t(X)%*%Y)

s <- split(dat$Bodyweight, dat$Diet)
mean(s[["chow"]])

mean(s[['hf']]) - mean(s[['chow']])

fit <- lm(Bodyweight ~ Diet, data=dat)
summary(fit)
(coefs <- coef(fit))

ttest <- t.test(s[["hf"]], s[["chow"]], var.equal=TRUE)
ttest$statistic
summary(fit)$coefficients[2,3]

fit2 <- glm(Bodyweight ~ Diet, data=dat, family="Binomial")


######################################################


set.seed(1)
B <- 10000
h0 <- 56.67
v0 <- 0
g <- 9.8
n <- 25
tt <- seq(0,3.4,len=n)
X <- cbind(1,tt,tt^2)
A <- solve(crossprod(X)) %*% t(X)
betahat <- replicate(B, { 
	y <- h0 + v0*tt -0.5*g*tt^2 + rnorm(n,sd=1)
	betahats <- A%*%y
	return(betahats[3])
})
head(betahat)
par(mfcol=c(1,2))
hist(betahat); qqnorm(betahat);qqline(betahat)

library(UsingR)
x <- father.son$fheight
y <- father.son$sheight
n <- length(y)

N <- 50
B <- 1000
betahat <- replicate(B, {
index <- sample(n,N)
sampledat <- father.son[index,]
x<- sampledat$fheight
y <- sampledat$sheight

lm(y ~ x)$coef
})
betahat <- t(betahat)

install.packages("rafalib")
library(rafalib)
mypar(1,2)
qqnorm(betahat[,1])
qqline(betahat[,1])
qqnorm(betahat[,2])
qqline(betahat[,2])