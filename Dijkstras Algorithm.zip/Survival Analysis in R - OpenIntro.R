install.packages("OIsurv")
library(OIsurv)
library(help=KMsurv)
library(help=survival)
library(help=OIsurv) # Survival analysis supplement to OpenIntro guide
data(aids)
attach(aids)
infect
detach(aids)
aids$infect

data(tongue)
str(tongue)
head(tongue)
summary(tongue)


surv_obj <- Surv(tongue$time[tongue$type==1], tongue$delta[tongue$type==1])
surv_obj

data(psych)
head(psych)
summary(psych)

  surv_obj2 <- Surv(psych$age, psych$age+psych$time, psych$death)
 surv_obj2
                   
 attach(tongue)
 survfit(surv_obj ~ 1)
survfit(surv_obj ~ 1, conf.int=0.90)

survfit(surv_obj ~ 1, conf.int=0.90, conf.type="log")  #default option uses g(t) = log(t)
                       
survfit(surv_obj ~ 1, conf.int=0.90, conf.type="log-log") # The "log-log" option uses g(t) = lgo(-log(t))
survfit(surv_obj ~ 1, conf.int=0.90, conf.type="plain") # A linear con dence interval is created
# savehistory("C:/Users/makarand.ghule/Desktop/abc.Rhistory")
my.fit <- survfit(surv_obj~1)
summary(my.fit)$surv
summary(my.fit)
str(my.fit)
str(summary(my.fit))
plot(my.fit)
plot(my.fit, main="Kaplan-Meier estimate with 95% confidence bounds",   xlab="time", ylab="survival function")
my.fit.tongue <- survfit(Surv(time, delta) ~ type)
summary(my.fit.tongue)
summary(my.fit.tongue)$strata

# Simultaneous con dence bands
data(bmt); attach(bmt)
head(bmt)
my.surv <- Surv(t2[group==1], d3[group==1])
my.cb <- confBands(my.surv, confLevel = 0.95, type='hall')
plot(survfit(my.surv ~ 1), xlim=c(100,600), 
     xlab='time', ylab='Estimated Survival Function', 
     main='Reproducing Confidance Bands for Example 4.2 in Klein/Moescheberger')


lines(my.cb$time, my.cb$lower, lty=3, type='s', col="red")
lines(my.cb$time, my.cb$upper, lty=3, type='s', col="red")
legend(100, 0.3, legend=c("K-M survival Estimate", "Pointwise Interval", "Confidance bands"), lty=1.3)
detach(bmt)

# Cumulative hazard function
data(tongue)
surv_obj <- Surv(tongue$time[tongue$type==1], tongue$delta[tongue$type==1])
my.fit <- summary(survfit(surv_obj ~ 1))
H.hat <- -log(my.fit$surv)
H_hat <- c(H.hat, tail(H.hat, 1))
h.sort.of <- my.fit$n.event / my.fit$n.risk
H_tilde <- cumsum(h.sort.of)
H_tilde <- c(H_tilde, tail(H_tilde, 1))
plot(c(my.fit$time, 250), H_hat, xlab="time", ylab="cumulative hazard", 
     main="comparing cumulative hazards", ylim=range(c(H_hat, H_tilde)), type="s")
points(c(my.fit$time, 250), H_tilde, lty=2, type="s")
legend("topleft", legend=c("H.hat","H_tilde"), lty=1:2)


# Mean and median estimates with bounds

