############# 1.INPUT ############# 


AttritionData <- read.csv("D:/HR/Attrition Analysis/R Analysis/AttritionData.csv")

MYdataset <- AttritionData

# colnames(MYdataset)
MYnobs <- nrow(MYdataset); MYnobs
str(MYdataset)
summary(MYdataset)

############# 2. EXPLORATION   ############
library(plyr);library(dplyr)

StatusCount<- as.data.frame.matrix(MYdataset %>%
                                     group_by(ExpAGSRange) %>%
                                     select(Availability_Filter) %>%
                                     table())
StatusCount$TOTAL<-StatusCount$`Current Employee` + StatusCount$`Employee Left`
StatusCount$PercentTerminated <-StatusCount$`Employee Left`/(StatusCount$TOTAL)*100
StatusCount
mean(StatusCount$PercentTerminated)

library(ggplot2)
ggplot() + geom_bar(aes(y = ..count.., x=as.factor(DepartmentGroup), fill = as.factor(Availability_Filter)), data=MYdataset, position=position_stack())


TerminatesData<- as.data.frame(MYdataset %>% 
                                 filter(Availability_Filter == "Employee Left"))
#exitType
ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

# Reason of Leaving
ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ReasonofLeaving)), data=TerminatesData, position = position_stack())

# Departments
ggplot() + geom_bar(aes(y=..count.., x=as.factor(Department), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

ggplot() + geom_bar(aes(y=..count.., x=as.factor(DepartmentGroup), fill=as.factor(ExitType)), data=TerminatesData, position = position_stack())

ggplot() + geom_bar(aes(y=..count.., x=as.factor(WorkLocation), fill=as.factor(Department)), data=TerminatesData, position = position_stack())


ggplot() + geom_bar(aes(y=..count.., x=as.factor(WorkLocation), fill=as.factor(Vertical)), data=TerminatesData, position = position_stack())


library(caret)
featurePlot(x=MYdataset[,c(15,17)], y=MYdataset$Availability_Filter, plot="density", auto.key=list(column=2))

featurePlot(x=MYdataset[,c(15,17)], y=MYdataset$Availability_Filter, plot="box", auto.key=list(column=2))


############# 3.Data Preparation ############# 

set.seed(100)


library(magrittr)


MYtrain <- subset(MYdataset, STATUS_YEAR <= 2015); nrow(MYtrain)

MYtest <- subset(MYdataset, STATUS_YEAR == 2016 & Department != 'Data Integration'); nrow(MYtest) 

# MYtest <- subset(MYdataset, STATUS_YEAR == 2016 ); nrow(MYtest) 

MYinput <- c('EmployeeAge',
             'MaritalStatus',
             'WorkLocation',
             'ProdAvgDuringNotice',
             'QualAvgDuringNotice',
             'Last30DaysLeaveCount',
             'EngagementIndex',
             # 'Department',
             # 'Shift_Name',
             # "Experience.Range",
             'Gender',
             'ExperienceInAGS'
)

# MYnumeric <- c( 'EmployeeAge',
#                 'ProdAvgDuringNotice',
#                 'QualAvgDuringNotice',
#                 'Last30DaysLeaveCount',
#                 'ExperienceInAGS'
# )


# MYcategoric <- c('MaritalStatus',
#                  'WorkLocation',
#                  'EngagementIndex',
#                  'Department',
#                  'Shift Name',
#                  'Experience Range',
#                  'Gender'
# )

MYvalidate <- NULL
MYrisk <- NULL
MYweights <- NULL


MYtarget <- "Attrition"

MYident <- "EmployeeCode"


MYTrainingData<-MYtrain[c(MYinput, MYtarget)]
MYTestingData<-MYtest[c(MYinput, MYtarget)]

# 2.2 Regression model ####



MYglm <- glm (Attrition ~ ., 
              data=MYTrainingData,
              family=binomial(link = "logit")
)


print(summary(MYglm))

cat(sprintf("Log likelihood: %.3f (%d df)\n",
            logLik(MYglm)[1],
            attr(logLik(MYglm), "df")))
cat(sprintf("Null/Residual deviance difference: %.3f (%d df)\n",
            MYglm$null.deviance-MYglm$deviance,
            MYglm$df.null-MYglm$df.residual))
cat(sprintf("Chi-square p-value: %.8f\n",
            dchisq(MYglm$null.deviance-MYglm$deviance,
                   MYglm$df.null-MYglm$df.residual)))
cat(sprintf("Pseudo R-Square (optimistic): %.8f\n",
            cor(MYglm$y, MYglm$fitted.values)))
cat('\n==== ANOVA ====\n\n')
print(anova(MYglm, test="Chisq"))


cat("\n")
#============================================================
# 3.Evaluate model performance Regression model. #####

# 3.2 Error Matrix for the Linear model ####

# response

MYpr <- as.vector(ifelse(predict(MYglm, type="response", 
                                 newdata=MYTestingData
                                 ) > 0.5, "1", "0"
                         )
                  )
# Confusion Matrix
table(MYTestingData$Attrition, MYpr, dnn=c("Actual", "Predicted"))

# Generate the confusion matrix showing proportions.

pcme <- function(actual, cl)
{
  x <- table(actual, cl)
  nc <- nrow(x)
  tbl <- cbind(x/length(actual),
               Error=sapply(1:nc,
                            function(r) round(sum(x[r,-r])/sum(x[r,]), 2)))
  names(attr(tbl, "dimnames")) <- c("Actual", "Predicted")
  return(tbl)
}
per <- pcme(MYTestingData$Attrition, MYpr)
round(per, 2)

# overall error percentage.

cat(100*round(1-sum(diag(per), na.rm=TRUE), 2))

# Calculate the averaged class error percentage.

cat(100*round(mean(per[,"Error"], na.rm=TRUE), 2))


#============================================================

# ROC Curve ####
library(ROCR); library(ggplot2, quietly=TRUE)

MYpr <- predict(MYglm, type="response", newdata=MYTestingData)

# Remove observations with missing target.

no.miss   <- na.omit(MYTestingData$Attrition)
miss.list <- attr(no.miss, "na.action")
attributes(no.miss) <- NULL

if (length(miss.list))
{
  pred <- prediction(MYpr[-miss.list], no.miss)
} else
{
  pred <- prediction(MYpr, no.miss)
}

pe <- performance(pred, "tpr", "fpr")
au <- performance(pred, "auc")@y.values[[1]]
pd <- data.frame(fpr=unlist(pe@x.values), tpr=unlist(pe@y.values))
p <- ggplot(pd, aes(x=fpr, y=tpr))
p <- p + geom_line(colour="red")
p <- p + xlab("False Positive Rate") + ylab("True Positive Rate")
p <- p + ggtitle("ROC Curve Linear [test] STATUS")
p <- p + theme(plot.title=element_text(size=10))
p <- p + geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="grey")
p <- p + annotate("text", x=0.50, y=0.00, hjust=0, vjust=0, size=5,
                  label=paste("AUC =", round(au, 2)))
print(p)

plot(0,type='n',axes=FALSE,ann=FALSE)

# and then print with newpage = F

print(data, newpage = F)
# AUC ####

performance(pred, "auc")

 #  Precision/Recall Plot ####

ROCR::plot(performance(pred, "prec", "rec"), col="#A300CCFF", lty=5, add=TRUE)

title(main="Precision/Recall Plot   [test]")
grid()


library(ROCR)

# Generate a Precision/Recall Plot for the glm model on MFG10YearTerminationData [test].

MYpr <- predict(MYglm, type="response", newdata=MYTestingData)

# Remove observations with missing target.

no.miss   <- na.omit(MYTestingData$Attrition)
miss.list <- attr(no.miss, "na.action")
attributes(no.miss) <- NULL

if (length(miss.list))
{
  pred <- prediction(MYpr[-miss.list], no.miss)
} else
{
  pred <- prediction(MYpr, no.miss)
}
# plot.new()
ROCR::plot(performance(pred, "prec", "rec"), col="#A300CCFF", lty=5, add=TRUE)

