rm(list=ls())
setwd("C:/Users/Makarand/Downloads/Analytics Edge - Final Exam")
Airlines = read.csv("AirlineDelay.csv")
str(Airlines)
summary(Airlines)
set.seed(15071)
spl=sample(nrow(Airlines), 0.7*nrow(Airlines))

AirlinesTrain = Airlines[spl,]
AirlinesTest = Airlines[-spl,]

nrow(AirlinesTrain)
nrow(AirlinesTest)
DelayLR = lm(TotalDelay ~., data = AirlinesTrain)
summary(DelayLR)
cor(AirlinesTrain$NumPrevFlights, AirlinesTrain$PrevFlightGap)  
cor(AirlinesTrain$OriginAvgWind, AirlinesTrain$OriginWindGust)


predLR = predict(DelayLR, newdata=AirlinesTest)


SSE = sum((AirlinesTest$TotalDelay - predLR)^2)
SSE
SST = sum((AirlinesTest$TotalDelay - mean(AirlinesTrain$TotalDelay))^2)
SST
#R2 = 
1- SSE/SST



Airlines$DelayClass = factor(ifelse(Airlines$TotalDelay == 0, "No Delay", ifelse(Airlines$TotalDelay >=30, "Major Delay", "Minor Delay")))
# summary(Airlines$DelayClass)
	
Airlines$TotalDelay = NULL
library(caTools)
set.seed(15071)
spl2 = sample.split(Airlines$DelayClass, SplitRatio = 0.7)
Airlines2Train = subset(Airlines, spl2 == TRUE)
Airlines2Test = subset(Airlines, spl2 == FALSE)
# Airlines2Train$DelayClass


library(rpart)
library(rpart.plot)

DelayCART = rpart(DelayClass ~ ., data= Airlines2Train, method = "class")
summary(DelayCART)
prp(DelayCART)
predTrainC = predict(DelayCART, type = "class")
confusionMatrix = table(Airlines2Train$DelayClass, predTrainC)
confusionMatrix
(361+3094)/(314+804+361+1806+188+3094)
BaselineModel = 
	table(Airlines2Train$DelayClass)
3282/nrow(Airlines2Train)



pred2Test = predict(DelayCART, newdata = Airlines2Test, type = "class")
table(Airlines2Test$DelayClass, pred2Test)
(153+1301)/(141+338+153+776+105+1301)
