library(devtools)
# install_github("genomicsclass/GSE5859Subset")
library(GSE5859Subset)
data(GSE5859Subset)
dim(geneExpression)
dim(sampleInfo)
head(sampleInfo)
summary(sampleInfo)
match(sampleInfo$filename, colnames(geneExpression))
dim(geneAnnotation)
head(geneAnnotation)
head(match(geneAnnotation$PROBEID,rownames(geneExpression)))


# p-values are random variables ####
library(downloader)
url <- "https://raw.githubusercontent.com/genomicsclass/dagdata/master/inst/extd\
ata/femaleControlsPopulation.csv"
filename <- basename(url)
download(url, destfile=filename)
set.seed(1)
population = unlist(read.csv("femaleControlsPopulation.csv"))

N <- 12
B <- 10000
pvals <- replicate(B, {
  control <- sample(population, N)
  treatment <- sample(population, N)
  t.test(control, treatment)$p.val
})
hist(pvals)
polygon(c(0,0,0.05, 0.05), c(0, hist(pvals)$count[1],  hist(pvals)$count[1], 0), col="red")
abline(v=0.05, lty = 3)


############### test P value for all genes ##################

library(GSE5859Subset)
data(GSE5859Subset)
g <- sampleInfo$group

e <- geneExpression[25,]
e


library(rafalib)
mypar(1,2)

qqnorm(e[g==1])
qqline(e[g==1])
qqnorm(e[g==0])
qqline(e[g==0])
mypar(1,2)
t.test(e[g==1],e[g==0])$p.value

set.seed(1)
myttest <- function(x) t.test(x[g==1],x[g==0], val.equal=TRUE)$p.value
pvals <- apply(geneExpression, 1,myttest)
min(pvals)

sum(pvals < 0.05)

set.seed(1)
m <- nrow(geneExpression)
n <- ncol(geneExpression)

randomData <- matrix(rnorm(n*m), m,n)
nullpvals <- apply(randomData, 1,myttest)
sum(nullpvals <0.05)

library(rafalib)
install_bioc("genefiter")
library("genefiter")

results <- rowttest(geneExpression, factor(g))
max(abs(pvals-results$p))


## Procedures ####
set.seed(1)
population = unlist(read.csv("femaleControlsPopulation.csv"))
alpha <- 0.05
N <- 12
B <- 10000
pvals <- replicate(B, {
  control = sample(population, N)
  treatment = sample(population, N)
  t.test(control, treatment)$p.value
  })
sum(pvals < alpha) #These many false positives are not acceptable in most contexts.

alpha <- 0.05
N <- 12
m <- 10000
p0 <- 0.90
m0 <- m*p0
m1 <- m-m0
nullHypothesis <- c(rep(TRUE, m0), rep(FALSE, m1))
delta <- 3 #effect size

set.seed(1)
calls <- sapply(1:m,function(i) {
  control <- sample(population, N)
  treatment <- sample(population, N)
  if(!nullHypothesis[i]) treatment <- treatment + delta
  ifelse(t.test(treatment, control)$p.value < alpha, 
         "called Significant", "not called Significant")
  })
null_Hypothesis <- factor(nullHypothesis, levels = c("TRUE", "FALSE"))
table(null_Hypothesis)
table(null_Hypothesis, calls)

# V and S are random variables. If we run the simulation repeatedly, these values change.

B <- 10
VnS <- replicate(B, {
  calls <- sapply(1:m, function(i) {
    control <- sample(population, N)
    treatment <- sample(population, N)
    if(!nullHypothesis[i]) treatment <- treatment + delta
    t.test(treatment, control)$p.val < alpha
  })
cat("V=", sum(nullHypothesis & calls), "S=", sum(!nullHypothesis & calls), "\n")
# c(sum(nullHypothesis & calls),sum(!nullHypothesis & calls))
  })



# The Bonferroni Correction

B <- 10000
set.seed(1)
minpval <- replicate(B, min(runif(10000,0,1)) < 0.05)
mean(minpval)

set.seed(1)
pvals <- sapply(1:m,function(i) {
  control <- sample(population, N)
  treatment <- sample(population, N)
  if(!nullHypothesis[i]) treatment <- treatment + delta
  t.test(treatment, control)$p.value
})
sum(pvals < 0.05/10000)


# small sample size
N <- 6
set.seed(1)
pvals <- sapply(1:m,function(i) {
  control <- sample(population, N)
  treatment <- sample(population, N)
  if(!nullHypothesis[i]) treatment <- treatment + delta
  t.test(treatment, control)$p.value
})
sum(pvals < 0.05/10000)



#vectorizing the operation
library(rafalib)
install_bioc("genefilter")
# library(genefilter)
# 
# 
# set.seed(1)
# g <- factor(c(rep(0,N),rep(1,N)))
# B <- 10000
# N <- 12
# Qs <- replicate(B, {
#   controls <- matrix(sample(population, N*m, replace=TRUE), nrow=m)
#   treatments <- matrix(sample(population, N*m, replace = TRUE), nrow=m)
#   treatments[which(!nullHypothesis), ] <- treatments[which(!nullHypothesis),] + delta
#   dat <- cbind(controls, treatments)
#   calls <- rowttests(dat,g)$p.value < alpha
#   R = sum(calls)
#   Q = ifelse(R >0, sum(nullHypothesis & calls)/R,0)
#   return(Q)
#   })
# 
# par(mfrow = c(1,1))
# hist(Qs)
# (FDR = mean(Qs))

library(genefilter) ##rowttests is here
set.seed(1)
##Define groups to be used with rowttests
g <- factor( c(rep(0,N),rep(1,N)) )
B <- 1000 ##number of simulations
Qs <- replicate(B,{
  ##matrix with control data (rows are tests, columns are mice)
  controls <- matrix(sample(population, N*m, replace=TRUE),nrow=m)
  ##matrix with control data (rows are tests, columns are mice)
  treatments <- matrix(sample(population, N*m, replace=TRUE),nrow=m)
  ##add effect to 10% of them
  treatments[which(!nullHypothesis),]<-treatments[which(!nullHypothesis),]+delta
  ##combine to form one matrix
  dat <- cbind(controls,treatments)
  calls <- rowttests(dat,g)$p.value < alpha
  R=sum(calls)
  Q=ifelse(R>0,sum(nullHypothesis & calls)/R,0)
  return(Q)
})
par(mfrow = c(1,1))
hist(Qs)
(FDR = mean(Qs))

set.seed(1)
controls <- matrix(sample(population, N*m, replace = TRUE), nrow=m)
treatments <- matrix(sample(population, N*m, replace=TRUE),nrow=m)
treatments[which(!nullHypothesis),]<-treatments[which(!nullHypothesis),]+delta
dat <- cbind(controls,treatments)
pvals <- rowttests(dat,g)$p.value
 h <- hist(pvals, breaks = seq(0,1,0.05))
 abline(h=m0/20)
 polygon(c(0,0.05,0.05,0), c(0,0,h$counts[1], h$counts[1]), col="grey")
 
 h <- hist(pvals, breaks=seq(0,1,0.01))
 abline(h=m0/100)
 polygon(c(0,0,0.01,0.01), c(0,h$counts[1], h$counts[1], 0), col="red")
 
 # Benjamini-Hochberg (Advanced)
 alpha <- 0.05
 (i=seq(along=pvals))
 mypar(1,1)
 plot(i,sort(pvals))
 abline(0,i/m*alpha)
 #close up 
 plot(i[1:15], sort(pvals)[1:15], main="Close Up")
 abline(0,i/m*alpha)
 
 k <- max( which( sort(pvals) < i/m*alpha) )
 cutoff <- sort(pvals)[k]
 cat("k =",k,"p-value cutoff=",cutoff)
 
 
 fdr <- p.adjust(pvals, method="fdr")
 mypar(1,1)
 plot(pvals,fdr,log="xy")
 abline(h=alpha,v=cutoff) ##cutoff was computed above
 
 
 
 ######### Basic Exploratory Data Analysis #####
 # Volcano Plots
library(genefilter)
library(GSE5859Subset) 
data(GSE5859Subset)
g <- factor(sampleInfo$group)
results <- rowttests(geneExpression,g)
pvals <- results$p.value

m <- nrow(geneExpression)
n <- ncol(geneExpression)
randomData <- matrix(rnorm(n*m),m,n)
nullpvals <- rowttests(randomData,g)$p.value

plot(results$dm, -log10(results$p.value), xlab="Effect Size", ylab="-log(base 10) p-vales")

# p-value Histogram
library(rafalib)
mypar(1,2)
hist(nullpvals, ylim=c(0,1400)); abline(v=0.05)
hist(pvals, ylim=c(0,1400)); abline(v=0.05)

mypar(1,1)
permg <- sample(g)
permresults <- rowttests(geneExpression, permg)
hist(permresults$p.value)
abline(v=0.05)


# Data boxplots and histograms
library(Biobase)
library(devtools)
# install_github("genomicsclass/GSE5859")
library(GSE5859)
data(GSE5859)
ge <- exprs(e)
# ge[,49] <- ge[,49]/log2(exp(1))
library(rafalib)
mypar(1,1)
boxplot(ge, range=0, names=1:ncol(e), col=ifelse(1:ncol(ge)==49,1,2))

# boxplot summaries
qs <- t(apply(ge,2,quantile, prob=c(0.05,0.25,0.5,0.75,0.95)))
matplot(qs, type= "l", lty=1)



# smooth histogram
mypar(1,1)
shist(ge, unit=0.5)

# Week 1 exercise
# install.packages("swirl")
library(swirl)
swirl()


library(GSE5859Subset)
data(GSE5859Subset)
d <- sampleInfo[sampleInfo$date == "2005-06-27",]
dim(d)
sum(geneAnnotation$CHR=="chrY",na.rm=TRUE)

               
id <- geneAnnotation[which(geneAnnotation$SYMBOL == "ARPC1A"), "PROBEID"]
file <- sampleInfo[which(sampleInfo$date == "2005-06-10"),"filename"]
geneExpression[rownames(geneExpression) == id,colnames(geneExpression) == file]    

median(apply(geneExpression,2,median))

## 5
library(GSE5859Subset)
data(GSE5859Subset)
g <- factor(sampleInfo$group)
# set.seed(1)
myttest <- function(e, group) {
  t.test(e[group==1], e[group == 0], var.equal = TRUE)$p.value
}
pvals <- apply(geneExpression,1,myttest, group=g)
min(pvals) # 1.406803e-21

# Inference in Practice Exercises

filename = "femaleControlsPopulation.csv"
population = read.csv(filename)

pvals <- replicate(1000, {
  control = sample(population[,1],12)
  treatment = sample(population[,1],12)
t.test(treatment, control)$p.val
  })
head(pvals)
hist(pvals)
mean(pvals < 0.01)


B <- 20
set.seed(100)

pvals <- replicate(B, {
  cases <- rnorm(10, 30, 2)
controls <-  rnorm(10,30,2)
t.test(cases, controls)$p.value
  })
sum(pvals < 0.05)





m <- 1000
B <- 20
set.seed(100)
pvl <- replicate (m, 
                  {
                    p <- replicate(B, {
                      cases <- rnorm(10,30,2)
                      control <- rnorm(10,30,2)
                      t.test(cases, control)$p.value
                     
                    })
                    sum( p <= 0.05)})

# pvl <- t(pvl)
mean(pvl)
table(pvl)/1000
mean(pvl > 0)
# 18968+1032
dim(pvl)
head(pvl)

#Error Rates and Procedures Exercises


B <- 8793
set.seed(100)

pvals <- replicate(B, {
  cases <- rnorm(10, 30, 2)
  controls <-  rnorm(10,30,2)
  t.test(cases, controls)$p.value
})
mean(pvals > 0)

B<-1000
minpval <- replicate(B, min(runif(8793,0,1))<0.000005)
mean(minpval>=1)
sum(minpval < 0.05/10000)



##
##warning this can take several minutes
##and will only give an approximate answer
B=10000
cutoffs = 10^seq(-7,-4,0.1) ##we know it has to be small
prob = sapply(cutoffs,function(cutoff){
  minpval =replicate(B, min(runif(8793,0,1))<=cutoff)
  mean(minpval>=1)
})
cutoffs[which.min(abs(prob-0.05))]

########## Bonferroni Correction Exercises #############
alphas <- seq(0,0.25,0.01)
par(mfrow=c(2,2))
for(m in c(2,10,100,1000)){
  plot(alphas,alphas/m - (1-(1-alphas)^(1/m)),type="l")
  abline(h=0,col=2,lty=2)
}

B <- 10000
set.seed(1)
minpval <- replicate(B, min(runif(8793,0,1)) < 0.05/8793)
mean(minpval>=1)
## ans
set.seed(1)
B <- 10000
m <- 8793
alpha <- 0.05
pvals <- matrix(runif(B*m, 0,1), B, m)
k <- alpha/m
mistakes <- rowSums(pvals < k)
mean(mistakes)

set.seed(1)
k <- (1-(1-alpha)^(1/m))
mistakes <- rowSums(pvals < k)
mean(mistakes)


### FDR Exercise ####
library(devtools)
library(rafalib)
library(GSE5859Subset)
library("genefilter")
# install_bioc("qvalue")

data(GSE5859Subset)
?rowttests
g <- factor(sampleInfo$group)
pvals <- rowttests(geneExpression, g)$p.val
(Q1 <- sum(pvals < 0.05))

(Q2 <- sum(pvals < (0.05/nrow(geneExpression))))

#Q3
library(qvalue)
g <- factor(sampleInfo$group)
pvals <- rowttests(geneExpression, g)$p.val
padj <- p.adjust(pvals, method="fdr") < 0.05
sum(padj)
qvals <- qvalue(pvals)
sum(qvals$qvalues < 0.05)
(pi0 = qvals$pi0)

plot(pvals, qvals$qvalues)
plot(qvalue(pvals)$qvalue/p.adjust(pvals,method="fdr"))
abline(h=qvalue(pvals)$pi0,col=2)
# To get an idea of how pi0 is estimated, note that if we look at the histogram, pi0 roughly tells us the proportion that looks about uniform:
hist(pvals,breaks=seq(0,1,len=21))
expectedfreq <- length(pvals)/20 #per bin
abline(h=expectedfreq*qvalue(pvals)$pi0,col=2,lty=2)


#Q7-12
n <- 12
m <- 8793
m1 = 500
m0 = m - m1
mat <- matrix(rnorm(n*m),m,n)
g <- factor( c(rep(0,n),rep(1,n)) )
B <- 1000
delta <- 2
positives <- 500
a <- 0.05
nullHypothesis <- c(rep(TRUE, m0), rep(FALSE, m1))
set.seed(1)

repl <- replicate(B, {
  case <- matrix(sample(mat, n*m, replace = TRUE), nrow=m)
  cont <- matrix(sample(mat, n*m, replace = TRUE), nrow=m)
  cont[1:positives,1:(n/2)] <- cont[1:positives,1:(n/2)]+delta
  cont[which(!nullHypothesis)] <- cont[which(!nullHypothesis)] + delta
  dat <- cbind(case, cont)
  calls <- rowttests(dat, g)$p.value < (a/m)
  R=sum(calls)
  Q=ifelse(R>0,sum(nullHypothesis & calls)/R,0)
  return(Q)
})
(FDR = mean(repl))



n <- 24
m <- 8793
mat <- matrix(rnorm(n*m),m,n)
N <- 12
delta <- 2
positives <- 500
mat[1:positives,1:(n/2)] <- mat[1:positives,1:(n/2)]+delta
m0 = 8293;m1=500

B <- 1000
nullHypothesis <- c(rep(TRUE, m0), rep(FALSE, m1))
g <- factor( c(rep(0,N),rep(1,N)) )

set.seed(1)

  pvals <- replicate(B, {
    controls <- matrix(sample(mat, N*m, replace=TRUE),nrow=m)
    treatments <- matrix(sample(mat, N*m, replace=TRUE),nrow=m)
    dat <- cbind(controls, treatments)
    calls <- rowttests(dat, g)$p.value < (a/m0)
    R=sum(calls)
    Q=ifelse(R>0,sum(nullHypothesis & calls)/R,0)
    return(Q)
  })
  FDR=mean(pvals)
  print(FDR)
  
  
  set.seed(1)
  library(qvalue)
  library(genefilter)
  n <- 24
  m <- 8793
  B <- 1000
  delta <-2
  positives <- 500
  g <- factor(rep(c(0,1),each=12))
  result <- replicate(B,{
    mat <- matrix(rnorm(n*m),m,n)
    mat[1:positives,1:(n/2)] <- mat[1:positives,1:(n/2)]+delta
    pvals = rowttests(mat,g)$p.val
    ##Bonferroni
    FP1 <- sum(pvals[-(1:positives)]<=0.05/m)  
    FP1
  })
  mean(result/(m-positives))
  # table(result, g)
  ##########################
  
  ## to install:
  library(rafalib)
  # install_bioc("SpikeInSubset")
  library(Biobase)
  library(SpikeInSubset)
  data(rma95)
  y <- exprs(rma95)
  
  pData(rma95)
  
  g <- factor(rep(0:1,each=3))
  
  library(genefilter)
  spike <- rownames(y) %in% colnames(pData(rma95))
  rtt <- rowttests(y,g)
  index = rtt$p.value < .01
  mean(!spike[index])
  
  
  mask <- with(rtt, abs(dm) < .2 & p.value < .01)
  cols <- ifelse(mask,"red",ifelse(spike,"dodgerblue","black"))
  with(rtt,plot(-dm, -log10(p.value), cex=.8, pch=16,
                xlim=c(-1,1), ylim=c(0,5),
                xlab="difference in means",
                col=cols))
  abline(h=2,v=c(-.2,.2), lty=2)
  
  
  library(dplyr)
  g <- factor(rep(0:1,each=3))
  spike <- rownames(y) %in% colnames(pData(rma95))
  rtt = rowttests(y,g)
  index = rtt$p.value < 0.01
  
  wg1sds<-data.frame("sds"=rowSds(y[,1:3]),spike,index)
  
  mypar(1,4)
  boxplot(sds~spike,data=wg1sds)
  boxplot(sds~index,data=wg1sds)
  
  wg1sds$cat<-ifelse(wg1sds$spike & wg1sds$index,"TP",ifelse(!wg1sds$spike & wg1sds$index,"FP",ifelse(wg1sds$spike & !wg1sds$index,"FN","TN")))
  
  table(wg1sds$cat)
  mypar(1,1)
  boxplot(sds~cat,data=wg1sds)
  
  # model answer
  library(genefilter)
  sds <- rowSds(y[,g==0])
  index <- paste0( as.numeric(spike), as.numeric(rtt$p.value<0.01))
  index <- factor(index,levels=c("11","01","00","10"),labels=c("TP","FP","TN","FN"))
  boxplot(split(sds,index))
  
  library(limma)
  fit <- lmFit(y, design=model.matrix(~ g))
  colnames(coef(fit))
  fit <- eBayes(fit)
  
  sampleSD = fit$sigma
  posteriorSD = sqrt(fit$s2.post)
  
  LIM = range( c(posteriorSD,sampleSD))
  plot(sampleSD, posteriorSD,ylim=LIM,xlim=LIM)
  abline(0,1)
  abline(v=sqrt(fit$s2.prior))
  
  library(limma)
  fit = lmFit(y, design=model.matrix(~ g))
  fit = eBayes(fit)
  ##second coefficient relates to diffences between group
  pvals = fit$p.value[,2] 
  newindex = pvals < 0.01
  print (mean( !spike[newindex] ))# is the answer
  
  ## We can make a volcano plot to visualize this:
  mask <- abs(fit$coef[,2]) < .2 & fit$p.value[,2] < .01
  cols <- ifelse(mask,"red",ifelse(spike,"dodgerblue","black"))
  plot(fit$coef[,2], -log10(fit$p.value[,2]), cex=.8, pch=16,
       xlim=c(-1,1), ylim=c(0,5),
       xlab="difference in means",
       col=cols)
  abline(h=2,v=c(-.2,.2), lty=2)
  
  