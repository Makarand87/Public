library(rafalib)
library(devtools)

# install_github("genomicsclass/dagdata")
library(dagdata)
library(help=dagdata)

data(admissions)
admissions$total = admissions$Percent*admissions$Number/100
# % Men
sum(admissions$total[admissions$Gender==1])/sum(admissions$Number[admissions$Gender==1])
# % Women
sum(admissions$total[admissions$Gender==0])/sum(admissions$Number[admissions$Gender==0])

index = admissions$Gender == 1
men <- admissions[index,]
women <- admissions[!index,]

menYes <- sum(men$total)
menNo <- sum(men$Number - men$total)
womenYes <- sum(women$total)
womenNo <- sum(women$Number - women$total)
tab <- matrix(c(menYes, womenYes, menNo, womenNo),2,2)
chisq.test(tab)$p.val

Y <- cbind(admissions[1:6,c(1,3)], admissions[7:12,3])
names(Y)[2:3] <- c("Male", "Female")
Y



###################

library(dagdata)
data(admissions)
print( admissions )

library(GSE5859)

index = which(admissions$Gender==1)
accepted = sum(admissions$Number[index]*admissions$Percent[index]/100)
applied = sum(admissions$Number[index])
accepted/applied


accepted0 = sum(admissions$Number[-index]*admissions$Percent[-index]/100)
applied0 = sum(admissions$Number[-index])
accepted0/applied0




######################

index = admissions$Gender==1
men = admissions[index,]
women = admissions[!index,]
menYes = sum(men$Number*men$Percent/100)
menNo = sum(men$Number*(1-men$Percent/100))
womenYes = sum(women$Number*women$Percent/100)
womenNo = sum(women$Number*(1-women$Percent/100))
tab <- matrix(c(menYes, womenYes, menNo, womenNo),2,2)
tab
chisq.test(tab)$p.value
print( data.frame( major=admissions[1:6,1],men=men[,3], women=women[,3]) )

H = (men$Number*men$Percent/100 + women$Number*women$Percent/100) / (men$Number+women$Number)
names(H) = ( LETTERS[1:6])
H
major <- admissions[1:6,1]
major[which.min(H)]
min(H)
cor(men$Number, H)
cor(women$Number, H)
