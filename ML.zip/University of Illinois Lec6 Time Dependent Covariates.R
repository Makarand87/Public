#Extended Example based on Stanford Heart Transplant data
library(survival)
data(heart)
head(heart)
head(jasa)
head(jasa1)
help(heart)
summary(heart)
str(heart)
fit1 <- coxph( Surv(start,stop,event)~(age + surgery)*transplant,
            data=heart, method='breslow')
fit1
summary(fit1)
#Now try to plot survival curves first for patients who never get a transplant
#Next for patients who don't have prior surgery and get a transplant immediately
#Note that there are no such patients in the sample so the latter is suspect
#Note that this syntax conflicts slightly with advice of p 51 of Therneau(1999)
fit1.1=survfit(fit1,data.frame(age=50,surgery=0,transplant="0"))
fit1.2=survfit(fit1,data.frame(age=50,surgery=0,transplant="1"))
par(mfrow=c(1,2))
plot(fit1.1)
plot(fit1.2)

#Now consider a more complicated case
#Joe is a hypothetical patient age 50 with prior surgery who gets a transplant
#after 6 months (183 days). Note that the event argument is ignored and the
#result of survfit estimates the survival curve for Joe under above scenario
Joe=data.frame(start=c(0,183),stop=c(183,3*365),event=c(1,1),age=c(50,50),
               surgery=c(1,1),transplant=c("0","1"))
Joe

fit1.3<- survfit(fit1,Joe,individual=T)
fit1.3
summary(fit1.3)
#Now plot all three fits
# postscript("fig1.ps", horizontal=F,width=7,height=3)
par(mfrow=c(1,3))
plot(fit1.1, main="No Transplant")
plot(fit1.2, main="No Prior Surgery but Immediate Transplant")
plot(fit1.3, main="Joe")

cox.zph(fit1)
