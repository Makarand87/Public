set.seed(1)
m = 10000
n = 24
x = matrix(rnorm(m*n),m,n)
colnames(x)=1:n

d <- dist(t(x))
h <- hclust(d)
plot(h)
csts <- cutree(h, h = 143)
max(csts)

m = 10000
n = 24
set.seed(1)
rep <- replicate(100, {
  x = matrix(rnorm(m*n),m,n)
  d <- dist(t(x))
  hc <- hclust(d)
  mx <- max(cutree(hc, h=143))
  return(mx)
  })
hist(rep)
sd(rep)/sqrt(10000)


})
plot(table(rep)) ## look at the distribution
popsd(nc) # unbiased estimate of sd


##############################
library(GSE5859Subset)
data(GSE5859Subset)
set.seed(10)

km <- kmeans(t(geneExpression),centers = 5)

mds <- cmdscale(dist(t(geneExpression)))
plot(mds[,1], mds[,2], col=km$cluster, pch=16)
table(sampleInfo$group,km$cluster)
table(sampleInfo$date,km$cluster)

table(sampleInfo$date,km$cluster)[,c(4,1,5,3,2)]


####################

library(GSE5859Subset)
data(GSE5859Subset)

# install.packages("matrixStats")
library(matrixStats)
?rowMads ##we use mads due to a outlier sample

rv <- rowMads(geneExpression)
idx <- order(-rv)[1:25]

library(gplots)
library(RColorBrewer)
library(rafalib)

hmcol <- colorRampPalette(brewer.pal(9, "GnBu"))(100)
cols  <- colorRampPalette(brewer.pal(8,"Dark2"))(2)[as.factor(sampleInfo$group)] # assigns a colour to each group


heatmap.2(geneExpression[idx,], 
          labCol=gsub("2005-","",sampleInfo$date),
          labRow = geneAnnotation$CHR[idx],
          trace = "none", 
          col=hmcol,
          ColSideColors=cols,
          scale="row")
length(rbinom(1000,1,0.25))


set.seed(17)
m = nrow(geneExpression)
n = ncol(geneExpression)
x = matrix(rnorm(m*n),m,n)
g = factor(sampleInfo$g )

library(genefilter)

ttest <- rowttests(x,g)
sds <- rowSds(x)

Index <- list(t=order(ttest$p.value)[1:50],s=order(-sds[1:50]))
mypar(1,2)
for(ind in Index) {
  heatmap.2(x[ind,],
            trace="none", 
            scale="row", 
            labCol = g,
            key = FALSE
            )
}



######## Classsification
n = 1000
y = rbinom(n,1,0.25)
##proportion of ones Pr(Y)
sum(y==1)/length(y)
##expectaion of Y
mean(y)

#
n = 10000
set.seed(1)
men = rnorm(n,176,7) #height in centimeters
women = rnorm(n,162,7) #height in centimeters
y = c(rep(0,n),rep(1,n))
x = round(c(men,women))
##mix it up
ind = sample(seq(along=y))
y = y[ind]
x = x[ind]




plot(x,y)
par(mfrow =c(1,2))
plot(x);plot(y)
par(mfrow =c(1,1))


data <- data.frame(x,y) 
mean(data$y)
d <- data[data$x==176,]
mean(d$y)
# mean(data[data$x==176,]$y)

subss <- data[data$x==seq(160,178), ]

mean(data[data$x==178,]$y)
mean(data[data$x==177,]$y)> 0.5
mean(data[data$x==176,]$y)> 0.5
mean(data[data$x==175,]$y)> 0.5
mean(data[data$x==174,]$y)> 0.5
mean(data[data$x==173,]$y)> 0.5
mean(data[data$x==172,]$y)> 0.5
mean(data[data$x==171,]$y)> 0.5
mean(data[data$x==170,]$y)> 0.5
mean(data[data$x==169,]$y)> 0.5
mean(data[data$x==168,]$y)> 0.5
mean(data[data$x==167,]$y)> 0.5
mean(data[data$x==166,]$y)> 0.5
mean(data[data$x==165,]$y)> 0.5
mean(data[data$x==164,]$y)> 0.5
mean(data[data$x==163,]$y)> 0.5
mean(data[data$x==162,]$y)> 0.5
mean(data[data$x==161,]$y)> 0.5
mean(data[data$x==160,]$y)> 0.5


# xs = seq(160,178)
# Pr =sapply(xs,function(x0) mean(Y[X==x0]))
for (i in seq(160, 178)) {
  print(round(mean(data[data$x==i,]$y),3))
}


for (i in seq(160, 178)) {
  print(cat("i=", i, prob = round(mean(data[data$x==i,]$y),3)))
}


xs = seq(160,178)
pr =sapply(xs,function(x0) mean(y[x==x0]))
plot(xs,pr)
abline(h=0.5)
abline(v=168)


#########################

n = 10000
set.seed(1)
men = rnorm(n,176,7) #height in centimeters
women = rnorm(n,162,7) #height in centimeters
y = c(rep(0,n),rep(1,n))
x = round(c(men,women))
##mix it up
ind = sample(seq(along=y))
y = y[ind]
x = x[ind]

set.seed(5)
N = 250
ind = sample(length(y),N)
Y = y[ind]
X = x[ind]
# Use loess to estimate f(x)=E(Y|X=x) using the default parameters. What is the predicted f(168)?
plot(X,Y)
fit <- loess(Y ~ X)
yhat <- predict(fit, newdata=data.frame(X=168))
yhat

##Here is a plot
xs = seq(160,178)
Pr =sapply(xs,function(x0) mean(Y[X==x0]))
plot(xs,Pr)
fitted=predict(fit,newdata=data.frame(X=xs))
lines(xs,fitted)

set.seed(5)
n=1000
N = 250
rep <- replicate(n, {
  ind=sample(length(y), N)
  Y = y[ind]
  X = x[ind]
  yhat <- predict(loess(Y ~ X), newdata=data.frame(X=168))
})

library(rafalib)
popsd(rep)
      

############
##plot plots are optional
set.seed(5)
B = 1000
N = 250
xs = seq(160,178)
plot(xs,xs,ylim=c(0,1),type="l")
res = replicate(B,{
  ind = sample(length(y),N)
  Y = y[ind]
  X = x[ind]
  fit=loess(Y~X)
  ##optional plots
  fitted=predict(fit,newdata=data.frame(X=xs))
  lines(xs,fitted)
  estimate = predict(fit,newdata=data.frame(X=168))
  return(estimate)
})
library(rafalib)
popsd(res)


########################
rm(list=ls())
library(GSE5859Subset)
data(GSE5859Subset)


y = factor(sampleInfo$group)
X = t(geneExpression)
out = which(geneAnnotation$CHR%in%c("chrX","chrY"))
X = X[,-out]

#
install.packages("caret")
library(caret)

set.seed(1)
idx <- createFolds(y=y, k = 10)
idx[[3]][2]

#
library(class)
library(genefilter)
m=8;k=5
ind=idx[[2]]
pvals <- rowttests(t(X[-ind,]), factor(y[-ind]))$p.val
ind2 <- order(pvals)[1:8]
predict <- knn(train = X[-ind, ind2], test = X[ind,ind2], cl=y[-ind], k=k)
table(true=y[idx[[2]] ], predict)
sum(predict!=y[ind])


set.seed(1)
ks <- 1:12
res <- sapply(ks, function(k) {
  ##try out each version of k from 1 to 12
  res.k <- sapply(seq_along(idx), function(i) {
    ##loop over each of the 10 cross-validation folds
    ##predict the held-out samples using k nearest neighbors
    ind <- idx[[i]]
    pvals <- rowttests(t(X[-ind,]), factor(y[-ind]))$p.val
    ind2 <- order(pvals)[1:8]
    pred <- knn(train = X[-ind, ind2], 
                test = X[ind,ind2], 
                cl=y[-ind], k=k)
    ##the ratio of misclassified samples
    mean(y[ idx[[i]] ] != pred)
  })
  ##average over the 10 folds
  mean(res.k)
})
  
res


set.seed(1)
m=8
ks <- 1:10
res <- sapply(ks, function(k) {
  ##try out each version of k from 1 to 10
  res.k <- sapply(seq_along(idx), function(i) {
    ##loop over each of the 10 cross-validation folds
    ##predict the held-out samples using k nearest neighbors
    ind=idx[[i]]
    pvals<-colttests(X[-ind,],factor(y[-ind]))$p.val # do ttests only on train set
    ind2<-order(pvals)[1:m]
    predict<-knn(train=X[-ind,ind2],test=X[ind,ind2],cl=y[-ind],k=k)
    ##the ratio of misclassified samples
    sum(predict!=y[ind])
  })
  ##average over the 10 folds
  sum(res.k)/length(y)
})
res

################
#############
set.seed(1)
m=8
ks <- 1:10
res <- sapply(ks, function(k) {
  ##try out each version of k from 1 to 10
  res.k <- sapply(seq_along(idx), function(i) {
    ##loop over each of the 10 cross-validation folds
    ##predict the held-out samples using k nearest neighbors
    ind=idx[[i]]
    pvals<-colttests(X[-ind,],factor(y[-ind]))$p.val # do ttests only on train set
    ind2<-order(pvals)[1:m]
    predict<-knn(train=X[-ind,ind2],test=X[ind,ind2],cl=y[-ind],k=k)
    ##the ratio of misclassified samples
    sum(predict!=y[ind])
  })
  ##average over the 10 folds
  sum(res.k)/length(y)
})
res
