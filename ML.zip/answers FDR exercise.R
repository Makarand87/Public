
library(devtools)
library(rafalib)
# install_github("genomicsclass/GSE5859Subset")
data(GSE5859Subset)
library("genefilter")
library("qvalue")

# Load gene expression data

#library(GSE5859Subset)


# We are interested in comparing gene expression between the two groups defined 
# in the sampleInfo table.

# Compute a p-value for each gene using the function rowttests from the genefilter
# package in Bioconductor.
library(genefilter)
?rowttests

alpha<-0.05
g <- factor(sampleInfo$group)
pvals<-rowttests(geneExpression,g)$p.value
sum(pvals<alpha)

# Apply the Bonferroni correction to the p-values obtained in question #1 to achieve
# a FWER of 0.05. How many genes are called significant under this procedure?

m<-nrow(pvals)
k <- alpha / m
sum(pvals<k)
# gives us list of 10 genes that we are quite certain has no false positives

# q values and the FDR (False Discovery Rate)
?p.adjust
g = factor(sampleInfo$group)
pvals = rowttests(geneExpression,g)$p.value
fdr = p.adjust(pvals,method="fdr")
sum(fdr<alpha)
# gives us list of 13 genes of which we think about 5% are false positives

# Now use the qvalue function, in the Bioconductor qvalue package,
# to estimate q-values using the procedure described by Storey.

library(qvalue)
?qvalue
g = factor(sampleInfo$group)
pvals = rowttests(geneExpression,g)$p.value
res<-qvalue(pvals)
sum(res$qvalues<alpha)
# gives us a list of 22 genes

# Read the help file for qvalue and report the estimated proportion of genes for which
# the null hypothesis is true ??0=m0/m
res$pi0

# Note that we have the number of genes passing the q-value <0.05 threshold is larger
# with the qvalue function than the p.adjust difference.

# This is because the qvalue function estimates the proportion of genes for which the
# null hypothesis is true and provides a less conservative estimate

plot(qvalue(pvals)$qvalue/p.adjust(pvals,method="fdr"))
abline(h=qvalue(pvals)$pi0,col=2)

hist(pvals,breaks=seq(0,1,len=21))
expectedfreq <- length(pvals)/20 #per bin
abline(h=expectedfreq*qvalue(pvals)$pi0,col=2,lty=2)

## FDR EXERCISES #7
# Create a Monte Carlo Simulation in which you simulate measurements from 8,793 genes
# for 24 samples: 12 cases and 12 controls.
n <- 24
m <- 8793
mat <- matrix(rnorm(n*m),m,n)

# Now for 500 genes, there is a difference of 2 between cases and controls:

delta <- 2
positives <- 500
mat[1:positives,1:(n/2)] <- mat[1:positives,1:(n/2)]+delta

# So the null hypothesis is true for 8793-500 genes.
# Using the notation from the videos m=8793, m0=8293 and m1=500

m0<-m-positives
m1<-positives
nullHypothesis <- c( rep(FALSE,m1), rep(TRUE,m0))


# Set the seed at 1, set.seed(1) and run this experiment 1,000 times with a
# Monte Carlo simulation. For each instance compute p-values using a t-test
# (using rowttests in the genefilter package) and create three lists of genes
# using:

# Bonferroni correction to achieve an FWER of 0.05,
# p-adjust estimates of FDR to achieve an FDR of 0.05, and
# qvalue estimates of FDR to to achieve an FDR of 0.05.

library(genefilter)
alpha<-0.05
g <- factor( c(rep(0,n/2),rep(1,n/2)) )



B <- 1000 ##number of simulations
n <- 24
m <- 8793
delta <- 2
positives <- 500
m0<-m-positives
m1<-positives
nullHypothesis <- c( rep(FALSE,m1), rep(TRUE,m0))
library(genefilter)
alpha<-0.05
g <- factor( c(rep(0,n/2),rep(1,n/2)) )

set.seed(1)
# bonferroni
ptab <- replicate(B,{
  mat <- matrix(rnorm(n*m),m,n)
  mat[1:positives,1:(n/2)] <- mat[1:positives,1:(n/2)]+delta
  # Bonferroni
  calls <- rowttests(mat,g)$p.value  < alpha/m # Bonferroni
  V1<-sum(calls & nullHypothesis)
  S1<-sum(calls & !nullHypothesis)
  #  qvalues from p.adjust
  pvals = rowttests(mat,g)$p.value
  calls <- p.adjust(pvals,method="fdr") < alpha # fdr
  V2<-sum(calls & nullHypothesis)
  S2<-sum(calls & !nullHypothesis)
  # qvalues from qvalue
  pvals = rowttests(mat,g)$p.value
  res<-qvalue(pvals)
  calls<-res$qvalues<alpha
  V3<-sum(calls & nullHypothesis)
  S3<-sum(calls & !nullHypothesis)    
  
  c(V1,S1,V2,S2,V3,S3)
})
FPR1<-sum(ptab[1,])/(B*m0)
FPR1
FNR1<-((B*m1)-sum(ptab[2,]))/(B*m1)
FNR1

FPR2<-sum(ptab[3,])/(B*m0)
FPR2
FNR2<-((B*m1)-sum(ptab[4,]))/(B*m1)
FNR2

FPR3<-sum(ptab[5,])/(B*m0)
FPR3
FNR3<-((B*m1)-sum(ptab[6,]))/(B*m1)
FNR3
